#ifndef _BITACORA_H_
#define _BITACORA_H_

#include <iostream>
#include <fstream>
#include <string>
#include <vector>

#include "Registro.h"
#include "IpReg.h"
#include "MaxHeap.h"

using std::string;
using std::ifstream;
using std::cout;
using std::ofstream;
using std::endl;
using std::vector;

// Clase para obtener los registros y realizar todo el proceso necesario.
 class Bitacora{

  public:
  	// Constructor que recibe como entrada: string 'filename' que es el nombre del archivo de la bitacora. Debe ser un archivo .txt
    Bitacora(string filenameI);
    // Destructor de Bitacora.
    ~Bitacora();

    // Carga los registros del archivo a la bitacora.
    void loadRegistros();
    // Muestra al usuario todos los registros de la bitacora.
    void showAllRegistros();
    // Muestra al usuario todas las ips de la bitacora.
    void showIps();
    // Ordena los registros de la bitacora mediante Heap Sort por ip de manera ascendente.
    void sort();
    // Cuenta la cantidad de apariciones de las ips y lo almacena en un MaxHeap.
    void contarIps();
    // Genera un archivo con los registros de la bitacora.
    void generateFileRegistros();
    // Genera un archivo con las ips de la bitacora.
    void generateFileIps();


  private:
  	/*
     * Variables que seran parte de cada registro:
     *   string 'filePath' para almacenar la cantidad de veces que aparece cada ip.
     *
     *   MaxHeap 'listaRegistros' de objetos de tipo Registro que almacena los registros de la bitacora.
     *   
     *   MaxHeap 'listaConteoIps' de objetos de tipo IpReg que almacena las ip's y su contador de los registros de la bitacora.
    */
    string filePath;
    MaxHeap<Registro> listaRegistros;
    MaxHeap<IpReg> listaConteoIps;
  
};

#endif