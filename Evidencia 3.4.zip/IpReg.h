#ifndef _IPREG_H_
#define _IPREG_H_

#include <iostream>
#include <string>
#include <vector>
#include <math.h>

using std::string;
using std::endl;
using std::vector;
using std::cout;
using std::ostream;

// Clase para los registros de Ips y su contador.
class IpReg{

  public:
  	// Constructor vacio.
    IpReg();
    // Constructor que recibe como entrada: string 'ipI', int 'counterI' para generar un registro.
    IpReg(string ipI, unsigned int ipBaseI, int counterI);
    // Destructor del registro.
    ~IpReg();

    // Sobrecarga de operadores comparativos para comparar registros utilizando su contador.
    bool operator ==(const IpReg&);
    bool operator !=(const IpReg&);
    bool operator >(const IpReg&);
    bool operator <(const IpReg&);
    bool operator <=(const IpReg&);
    bool operator >=(const IpReg&);

    // Sobrecarga de operador << para imprimir toda la informacion del registro.
    friend ostream& operator<<(ostream& os, const IpReg& ipReg);

  private:
  	/*
     * Variables que seran parte de cada registro:
     *   Entero 'counter' para almacenar la cantidad de veces que aparece cada ip.
     *
     *   Unsigned int 'ipBase' para almacenar el valor de la ip de base 256 en base decimal.
     *   
     *   String 'ip' para almacenar la direcion ip de cada registro.
    */
    int counter;
    unsigned int ipBase;
    string ip;
    
};

#endif