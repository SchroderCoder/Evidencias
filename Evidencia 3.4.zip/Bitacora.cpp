#include "Bitacora.h"


/*
 * Método Bitacora:
 * Descripción: Genera un objeto del tipo Bitacora con sus variables tomando los valores recibidos en los parametros.
 * Entrada: string 'filenameI' que es el nombre del archivo en formato "nombre.txt"
 * Salida: Ninguna
 * Precondición: Recibir el nombre en formato "nombre.txt".
 * Postcondición: Se genera una nueva Bitacora con el nombre del archivo en la variable 'filePath'.
 * Complejidad: O(n) debido a los MaxHeap.
*/

Bitacora::Bitacora(string filenameI){

  // Se asigna a la variable filePath el nombre del archivo recibido como parametro de filenameI.
  filePath = filenameI;

  // Se genera el MaxHeap 'listaRegistro' con capacidad de 16,900.
  MaxHeap<Registro> listaRegistro(16900);
  // Se genera el MaxHeap 'listaConteosIps' con capacidad de 5,000.
  MaxHeap<IpReg> listaConteosIps(5000);
}

// Destructor vacio del objeto tipo Bitacora.
Bitacora::~Bitacora(){
  
}


/*
 * Método loadRegistros:
 * Descripción: Lee un archivo y genera los registros con la informacion del mismo. En caso de no poder hacerlo, manda un error.
 * Entrada: Nada
 * Salida: Nada
 * Precondición: Tener un archivo .txt valido con los registros que seran cargados a la bitacora.
 * Postcondición: El MaxHeap 'listaRegistros' con los registros generados a partir del archivo.
 * Complejidad: O(n)
*/

void Bitacora::loadRegistros(){
  // Se genera un ifstream 'MyReadFile' con el nombre del archivo previamente almacenado en 'filePath'.
  ifstream MyReadFile(filePath);
  MyReadFile.exceptions ( ifstream::badbit );

  // Se checa si se puede abrir adecuadamente el archivo.
  if(MyReadFile.is_open()){
    string myText;
    
    // Se obtiene cada linea del archivo para obtener la informacion de cada registro.
    while (getline(MyReadFile, myText)){
      
      // Se obtiene el mes:
      string text = myText;
      int pos = text.find(" ");
      string mes = text.substr(0,pos);

      // Se obtiene el día:
      text = text.substr(pos+1);
      pos = text.find(" ");
      string dia = text.substr(0,pos);
  
      // Se obtiene la hora:
      text = text.substr(pos+1);
      pos = text.find(" ");
      string hora = text.substr(0,pos);
  
      // Se obtiene la ip:
      text = text.substr(pos+1);
      pos = text.find(" ");
      string ip = text.substr(0,pos);
  
      // Se obtiene el motivo:
      string motivo = text.substr(pos+1);

      // Se genera el registro:
      Registro reg = Registro(mes, dia, hora, ip, motivo);
      listaRegistros.push(reg);
    }
    // Se cierra el archivo.
    MyReadFile.close();
  }
  // En caso de no poder abrir el archivo adecuadamente, se arroja un error.
  else {
    MyReadFile.close();
    throw std::invalid_argument("Error en la lectura de archivo.");
  }
}


/*
 * Método showAllRegistros:
 * Descripción: Despliega en pantalla todos los registros de la bitacora.
 * Entrada: Nada
 * Salida: Imprime todos los registros de la bitacora.
 * Precondición: Que haya una bitacora con Registros valida.
 * Postcondición: Imprime los registros de la bitacora.
 * Complejidad: O(n)
*/

void Bitacora::showAllRegistros(){
    listaRegistros.printMaxHeap();
}


/*
 * Método showIps:
 * Descripción: Despliega en pantalla todas las ips con su cantidad de apariciones de la bitacora.
 * Entrada: Nada
 * Salida: Imprime todas las ips con su cantidad de apariciones de la bitacora.
 * Precondición: Que haya una bitacora con ips validas.
 * Postcondición: Imprime las ips con su cantidad de apariciones de la bitacora.
 * Complejidad: O(n)
*/

void Bitacora::showIps(){
  listaConteoIps.printMaxHeap();
}


/*
 * Método sort:
 * Descripción: Ordena los elementos de 'listaRegistros' mediante el uso del metodo heapSort de 'MaxHeap' que implementa un Heap Sort.
 * Entrada: Ninguna.
 * Salida: Ninguna.
 * Precondición: Una bitacora con MaxHeap 'listaRegistros' con n Registros.
 * Postcondición: El MaxHeap 'listaRegistros' con n Registros ordenada de forma ascendente por ip.
 * Complejidad: O(n log(n))
*/

void Bitacora::sort(){
   listaRegistros.heapSort();
}


/*
 * Método contarIps:
 * Descripción: Cuenta la cantidad de veces que se repite cada ip y genera un registro para el MaxHeap 'listaConteoIps'.
 * Entrada: Ninguna.
 * Salida: Ninguna.
 * Precondición: 'listaRegistros' debe estar ordenada.
 * Postcondición: 'listaConteoIps' debe de contar con los registros de ips con su conteo.
 * Complejidad: O(n)
*/

void Bitacora::contarIps(){
  int i = 0;
  while (i < listaRegistros.getSize()){
    int j, counter;
    j = i+1;
    counter = 1;
    while(j < listaRegistros.getSize() && listaRegistros[i]==listaRegistros[j]){
      j++;
      counter++;
    }
    IpReg reg = IpReg(listaRegistros[i].getIp(), listaRegistros[i].getIpBase(), counter);
    listaConteoIps.push(reg);
    i = j;
  }
}


/* 
 * Método generateFileRegistros:
 * Descripción: Genera un archivo .txt donde se almacenan los registros de la bitacora ordenada.
 * Entrada: Ninguna.
 * Salida: Archivo .txt con los registros de la bitacora, uno por linea.
 * Precondición: Bitacora con 'listaRegistros' con registros validos.
 * Postcondición: Archivo con nombre "bitacora_ordenada.txt" con los registros de la bitacora.
 * Complejidad: O(n)
*/

void Bitacora::generateFileRegistros(){
  listaRegistros.generateFileHeap("bitacora_ordenada.txt", listaRegistros.getSize());
}


/* 
 * Método generateFileIps:
 * Descripción: Genera un archivo .txt donde se almacenan los registros de ips con sus repeticiones de la bitacora ordenada. Son las primeras cinco ips con mas repeticiones.
 * Entrada: Ninguna.
 * Salida: Archivo .txt con los registros de ips con sus repeticiones de la bitacora, uno por linea hasta cinco.
 * Precondición: Un MaxHeap 'listaConteoIps' con mas de cinco ips.
 * Postcondición: Archivo con nombre "ips_con_mayor_acceso.txt" con las cinco ips mas repetidas de la bitacora.
 * Complejidad: O(1) Debido a que es constante el numero (5).
*/

void Bitacora::generateFileIps(){
  listaConteoIps.generateFileHeapPopPriority("ips_con_mayor_acceso.txt", 5);
}