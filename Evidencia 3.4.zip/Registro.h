#ifndef _REGISTRO_H_
#define _REGISTRO_H_

#include <iostream>
#include <string>
#include <vector>
#include <math.h>

using std::string;
using std::endl;
using std::vector;
using std::cout;
using std::ostream;

// Clase para los registros.
class Registro{

  public:
    // Constructor vacio.
    Registro();
    // Constructor que recibe como entrada: String 'mesI', String 'diaI', String 'horaI', String 'ipI', String 'motivoI' para generar un registro.
    Registro(string mesI, string diaI, string horaI, string ipI, string motivoI);
    // Destructor del registro.
    ~Registro();

    // Metodo que devuelve un string con toda la informacion del registro.
    string getRegistro();
    // Metodo que devuelve la fecha del registro como tipo de dato time_t.
    time_t getDate();
    // Metodo que devuelve el valor de la Ip en base 256 como unsigned int.
    unsigned int getIpBase();
    // Metodo que devuelve la Ip con formato string.
    string getIp();

    // Sobrecarga de operadores comparativos para comparar registros utilizando su ip en base 256.
    bool operator ==(const Registro&);
    bool operator !=(const Registro&);
    bool operator >(const Registro&);
    bool operator <(const Registro&);
    bool operator <=(const Registro&);
    bool operator >=(const Registro&);

    // Sobrecarga de operador << para imprimir toda la informacion del registro.
    friend ostream& operator<<(ostream& os, const Registro& reg);
    
  private:
    /*
     * Variables que seran parte de cada registro:
     *   Entero 'dia' para almacenar el dia de cada registro.
     *   Entero 'hora' para almacenar la hora de cada registro.
     *   Entero 'minuto' para almacenar el minuto de cada registro.
     *   Entero 'segundo' para almacenar el segundo de cada registro.
     *   Entero 'puertoBase' para almacenar el puerto de cada ip de cada registro.
     *
     *   Unsigned int 'ipBase' para almacenar el valor de la ip de base 256 en base decimal.
     *
     *   String 'mes' para almacenar el mes de cada registro.
     *   String 'horaT' para almacenar en formato "hh:mm:ss" la hora de cada registro.
     *   String 'ip' para almacenar la direcion ip de cada registro.
     *   String 'motivo' para almacenar el motivo de cada registro.
     *   String 'diaT' para almacenar el dia en formato "dd" de cada registro.
     *   String 'puerto' para almacenar el puerto de cada registro.
    */
    int dia, hora, minuto, segundo, puertoBase;
    unsigned int ipBase;
    string mes, horaT, ip, motivo, diaT, puerto;

    // Vector tipo string que incluye las primeras tres letras de cada mes como elementos.
    vector<string> meses = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
    // Struct que contiene todos los datos de la fecha-hora
    struct tm dateStruct;
    // Unix timestamp (segundos transcurridos desde 00:00 hrs, Jan 1, 1970 UTC)
    time_t date;

};


#endif