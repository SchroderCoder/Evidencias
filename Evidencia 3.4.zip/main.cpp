/*
 * Fecha: 21 de mayo 2022
 *
 * Matrícula: A01652327
 * Nombre: Diego Esparza Hurtado
 *
 * Matrícula: A01707503
 * Nombre: Carlos Adrián García Estrada
 * 
 * Act 3.4 - Actividad Integral de BST
 *
 * El programa consiste en recibir una bitacora con registros y lo ordena por ips, además cuenta la cantidad de veces que aparece cada una.
 *      El programa debe recibir el archivo con los registros a ordenar y genera un archivo nuevo con los registros ordenados.
 *      Cuenta la cantidad de veces que cada direccion ip se repite y genera un archivo con las cinco ip's que mas se repiten con su cantidad de apariciones.
 * 
 * Compilacion para debug:  
 *    g++ -std=c++17 -g -o main *.cpp
 *
 * Ejecucion con valgrind:
 *    nix-env -iA nixpkgs.valgrind
 *    valgrind --leak-check=full ./main
 *
 * Compilacion para ejecucion:  
 *    g++ -std=c++17 -O3 -o main *.cpp
 * Ejecucion:
 *    ./main
*/

#include <iostream>
#include <fstream>
#include <string>
#include <vector>

using std::cin;
using std::cout;

#include "Bitacora.h"

int main() {

    // Se genera un nuevo objeto tipo Bitacora que recibe el nombre del archivo .txt.
    Bitacora bitacora("bitacoraHeap.txt");

    // Se cargan los registros del archivo .txt solicitado previamente.
    try{
        bitacora.loadRegistros();
    }
    catch(std::exception const& e){
        cout << "There was an error: " << e.what() << endl;
    }
    catch (...){
        cout << "Error desconocido" << endl;
    }

    // Se ordenan los registros del objeto bitacora.
    bitacora.sort();

    // Se genera un archivo con los datos de la bitacora ordenada.
    bitacora.generateFileRegistros();

    // Se cuentan las ips y se genera un MaxHeap con la cantidad de repeticiones.
    bitacora.contarIps();

    // Se genera un archivo con las cinco ips mas repetidas.
    bitacora.generateFileIps();

    return 0;

}


/*
 * Referencias:
 * https://docs.microsoft.com/en-us/cpp/standard-library/overloading-the-output-operator-for-your-own-classes?view=msvc-170
 * https://www.geeksforgeeks.org/heap-sort/
 *
 *
 *
 *
 *
*/