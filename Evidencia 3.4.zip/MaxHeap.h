#ifndef __MAXHEAP_H_
#define __MAXHEAP_H_

  #include <vector>
  #include <iostream>
  #include <stdexcept>
	#include <fstream>
  #include <string>

  using std::string;
  using std::cout;
  using std::endl;
  using std::string;
  using std::ofstream;
  using std::vector;


  template<class T>
  class MaxHeap {
    private:
     /*
      * Variables que seran parte de cada registro:
      *   vector 'data' que contiene los elementos del heap.
      *
      *   Entero 'maxSize' que es la capacidad maxima del heap.
      *   
      *   Entero 'size' que es el tamaño actual del heap.
     */
      vector<T> data; 
      int maxSize;
      int size;

      // Metodo para obtener el padre de un nodo.
      int parent(int i);
      // Metodo para obtener el hijo izquierdo de un nodo.
      int left(int i);
      // Metodo para obtener el hijo derecho de un nodo.
      int right(int i);

    public:
      // Constructor vacio.
      MaxHeap();
      // Constructor que recibe como entrada: int 'capacity' para generar un MaxHeap.
      MaxHeap(int capacity);
      // Destructor del MaxHeap.
      ~MaxHeap();
      // Metodo para checar si el MaxHeap esta vacio.
      bool isEmpty();
      // Metodo que devuelve la capacidad del MaxHeap.
      int getCapacity();
      // Metodo que imprime el MaxHeap.
      void printMaxHeap();
      // Metodo que ingresa un nuevo elemento al MaxHeap.
      void push(T key);
      // Metodo que devuelve el valor con mas prioridad del MaxHeap.
      T top();
      // Metodo que elimina el valor con mas prioridad del MaxHeap.
      void pop();
      // Metodo que devuelve el tamaño actual del MaxHeap.
      int getSize();
      // Metodo que ordena de forma ascendente el MaxHeap.
      void heapSort();
      // Cuidar las propiedades del MaxHeap.
      void heapify(int n, int i);
      // Sobrecarga del operador []
      T& operator[](int x);
      // Metodo para generar un archivo con los datos del MaxHeap.
			void generateFileHeap(string filename, int n);
      // Metodo para generar un archivo con los datos con mas prioridad.
			void generateFileHeapPopPriority(string filename, int n);

  };


  /*
   * Método MaxHeap:
   * Descripción: Genera un objeto del tipo MaxHeap.
   * Entrada: Ninguna.
   * Salida: Ninguna.
   * Precondición: Ninguna.
   * Postcondición: Se genera un nuevo MaxHeap con sus respectivas variables.
   * Complejidad: O(n) debido a resize.
  */

  template <class T> 
  MaxHeap<T>::MaxHeap() {
      // std::cout << "--->Creando un MaxHeap: " <<  this << std::endl;
      size = 0;
      maxSize = 16900;
      data.resize(maxSize);
  }


  /*
   * Método MaxHeap:
   * Descripción: Genera un objeto del tipo MaxHeap.
   * Entrada: Entero 'capacity' con la capacidad maxima que tendra el MaxHeap.
   * Salida: Ninguna.
   * Precondición: Que se reciba adecuadamente el entero 'capacity'.
   * Postcondición: Se genera un nuevo MaxHeap con sus respectivas variables.
   * Complejidad: O(n) debido a resize.
  */

  template <class T> 
  MaxHeap<T>::MaxHeap(int capacity) {
      // cout << "--->Creando un MaxHeap: " <<  this << std::endl;
      size = 0;
      maxSize = capacity;
      data.resize(maxSize);
  }


  /*
   * Método ~MaxHeap:
   * Descripción: Destruye un objeto del tipo MaxHeap.
   * Entrada: Ninguna.
   * Salida: Ninguna
   * Precondición: Un MaxHeap valido.
   * Postcondición: MaxHeap vacio.
   * Complejidad: O(n)
  */

  template <class T> 
  MaxHeap<T>::~MaxHeap() {
      // cout << "--->Liberando memoria del MaxHeap: " <<  this << std::endl;
      data.clear();
  }


  /*
   * Método isEmpty:
   * Descripción: Regresa un valor boleando diciendo si la fila priorizada está vacía o tiene datos.
   * Entrada: Ninguna.
   * Salida: Un valor booleano que diga si la fila priorizada está vacía o tiene datos.
   * Precondición: Ninguna.
   * Postcondición: Ninguna.
   * Complejidad: O(1)
  */

  template <class T> 
  bool MaxHeap<T>::isEmpty() {
    return (size <= 0);
  }


  /*
   * Método getCapacity:
   * Descripción: Regresa la capacidad que tiene la fila priorizada.
   * Entrada: Ninguna.
   * Salida: Valor de la capacidad maxima que tiene la fila priorizada.
   * Precondición: Una fila priorizada valida.
   * Postcondición: Regresar la capacidad que tiene la fila priorizada.
   * Complejidad: O(1)
  */

  template <class T> 
  int MaxHeap<T>::getCapacity() {
    return maxSize;
  }


  /*
   * Método printMaxHeap:
   * Descripción: Imprime todos los elementos de la fila priorizada.
   * Entrada: Ninguna.
   * Salida: Todos los elementos de la fila priorizada.
   * Precondición: Una fila priorizada valida.
   * Postcondición: Que se impriman todos los elementos de la fila priorizada.
   * Complejidad: O(n)
  */

  template <class T> 
  void MaxHeap<T>::printMaxHeap() {
    for (int i=0; i < size; i++)
      cout << data[i] << endl;
    cout << endl;
  }


  /*
   * Método parent:
   * Descripción: Devuelve el padre de un nodo.
   * Entrada: Entero 'i' que es el lugar un nodo.
   * Salida: El valor de index del padre de un nodo.
   * Precondición: Un valor entero valido.
   * Postcondición: El valor de index del padre de un nodo.
   * Complejidad: O(1)
  */

  template <class T> 
  int MaxHeap<T>::parent(int i) {
    return (i-1)/2; 
  }


  /*
   * Método left:
   * Descripción: Devuelve el hijo izquierdo de un nodo.
   * Entrada: Entero 'i' que es el lugar un nodo.
   * Salida: El valor de index del hijo izquierdo de un nodo.
   * Precondición: Un valor entero valido.
   * Postcondición: El valor de index del hijo izquierdo de un nodo.
   * Complejidad: O(1)
  */

  template <class T> 
  int MaxHeap<T>::left(int i) {
    return (2*i + 1); 
  }


  /*
   * Método left:
   * Descripción: Devuelve el hijo derecho de un nodo.
   * Entrada: Entero 'i' que es el lugar un nodo.
   * Salida: El valor de index del hijo derecho de un nodo.
   * Precondición: Un valor entero valido.
   * Postcondición: El valor de index del hijo derecho de un nodo.
   * Complejidad: O(1)
  */

  template <class T> 
  int MaxHeap<T>::right(int i) {
    return (2*i + 2);
  }


  /*
   * Método push:
   * Descripción: Agregue un dato a la fila priorizada.
   * Entrada: Valor 'key' el cual se desea agregar a la fila priorizada.
   * Salida: Ninguna.
   * Precondición: N es un valor.
   * Postcondición: La fila priorizada contiene un nuevo dato.
   * Complejidad: O(log n)
  */

  template <class T> 
  void MaxHeap<T>::push(T key) {
    if (size == maxSize) {
      throw std::out_of_range("Overflow: no se puede insertar la llave.");
    }
    // Insertamos la nueva llave al final del vector
    int i = size;
    data[i] = key;
    size++;
    // Reparar las propiedades del max heap si son violadas
    while (i != 0 && data[parent(i)] < data[i]) {
       std::swap(data[i], data[parent(i)]);
       i = parent(i);
    }
  }


  /*
   * Método top:
   * Descripción: Regresa el valor del dato que está con mayor prioridad en la fila priorizada.
   * Entrada: Ninguna.
   * Salida: El dato que tiene mayor prioridad dentro de la fila priorizada.
   * Precondición: Que la fila priorizada contenga al menos 1 dato.
   * Postcondición: Ninguna.
   * Complejidad: O(1)
  */

  template <class T> 
  T MaxHeap<T>::top() {
    if (isEmpty()) {
      throw std::out_of_range(" El heap no tiene datos " );
    }
    else{
      return data[0];
    }
  }


  /*
   * Método pop:
   * Descripción: Saca de la fila priorizada el dato que tiene mayor prioridad.
   * Entrada: Ninguna.
   * Salida: Ninguna.
   * Precondición: Que la fila priorizada contenga al menos 1 dato.
   * Postcondición: La fila priorizada queda sin el dato con mayor prioridad.
   * Complejidad: O(log n)
  */

  template <class T> 
   void MaxHeap<T>::pop() {
		if (isEmpty()) {
      throw std::out_of_range(" El heap no tiene datos " );
    }
		T temp;
		data[0]= temp;
		data[0]= data[size-1];
		data[size-1]= temp;
		size--;
		int i = 0;

		data.pop_back();

    // Reparar las propiedades del max heap si son violadas
    while (data[i] < data[left(i)] || data[i] < data[right(i)] ) {
			if (data[right(i)] >= data[left(i)]){
				std::swap(data[i], data[right(i)]);
				i = right(i);
			}
			else{
				std::swap(data[i], data[left(i)]);
				i = left(i);
			}
       
    }
  }


  /*
   * Método getSize:
   * Descripción: Regresa la cantidad de datos que tiene la fila priorizada.
   * Entrada: Ninguna.
   * Salida: Un valor entero que representa la cantidad de datos de la fila priorizada.
   * Precondición: Ninguna.
   * Postcondición: Ninguna.
   * Complejidad: O(1)
  */

  template <class T> 
  int MaxHeap<T>::getSize() {
    return size;
  }


  /*
   * Método heapify:
   * Descripción: Mantiene la fila priorizada de manera adecuada.
   * Entrada: Entero 'n' que es el tamaño de la fila; Entero 'i' que es el indice del nodo root.
   * Salida: Ninguna.
   * Precondición: Una fila priorizada valida
   * Postcondición: Una fila priorizada con un orden adecuado.
   * Complejidad: O(log n)
  */

  template <class T>
  void MaxHeap<T>::heapify(int n, int i) {
   
    int largest = i;
    int l = left(i);
    int r = right(i);
 
    if (l < n && data[l] > data[largest])
        largest = l;
 
    if (r < n && data[r] > data[largest])
        largest = r;
 
    if (largest != i) {
        std::swap(data[i], data[largest]);
 
        heapify(n, largest);
    }
  }


  /*
   * Método heapSort:
   * Descripción: Ordena de manera ascendente la fila priorizada.
   * Entrada: Ninguna.
   * Salida: Ninguna.
   * Precondición: Una fila priorizada valida.
   * Postcondición: Una fila priorizada ordenada de manera ascendente.
   * Complejidad: O(n log(n))
  */

  template <class T>
  void MaxHeap<T>::heapSort(){
   
    // Se ordena la fila priorizada.
    for (int i = size / 2 - 1; i >= 0; i--)
        heapify(size, i);
 
    for (int i = size - 1; i > 0; i--) {
       
        std::swap(data[0], data[i]);
 
        heapify(i, 0);
    }
  }


  /*
   * Método Sobrecarga []:
   * Descripción: Devuelve el valor del MaxHeap en el indice insertado.
   * Entrada: Un entero con la posicion.
   * Salida: Devuelve el valor del MaxHeap en el indice insertado.
   * Precondición: Una fila priorizada valida.
   * Postcondición: Devuelve el valor del MaxHeap en el indice insertado.
   * Complejidad: O(1)
  */

  template <class T>
  T& MaxHeap<T>::operator[] (int x) {
    return data[x];
  }


  /*
   * Método generateFileHeap:
   * Descripción: Genera un archivo .txt donde se almacenan los datos de la fila priorizada.
   * Entrada: string 'filename' que es el nombre que tendra el archivo; int 'n' que es el numero de elementos a imprimir.
   * Salida: Archivo .txt con los datos de la fila priorizada, uno por linea.
   * Precondición: Una fila priorizada valida.
   * Postcondición: Archivo .txt con los datos de la fila priorizada, uno por linea.
   * Complejidad: O(n)
  */

  template <class T>
  void MaxHeap<T>::generateFileHeap(string filename, int n){
	 ofstream MyFile(filename);
    for(int i=0; i<n; i++) {
			MyFile << data[i] <<endl;
	 }
  }


  /*
   * Método generateFileHeapPopPriority:
   * Descripción: Genera un archivo .txt donde se almacenan los datos de la fila priorizada.
   * Entrada: string 'filename' que es el nombre que tendra el archivo; int 'n' que es el numero de elementos a imprimir.
   * Salida: Archivo .txt con los datos de la fila priorizada, uno por linea, de mayor prioridad.
   * Precondición: Una fila priorizada valida.
   * Postcondición: Archivo .txt con los datos de la fila priorizada, uno por linea, de mayor prioridad.
   * Complejidad: O(n)
  */

  template <class T>
  void MaxHeap<T>::generateFileHeapPopPriority(string filename, int n){
	 ofstream MyFile(filename);
    for(int i=0; i<n; i++) {
			MyFile << top() <<endl;
      pop();
	 }
  }

#endif // __MAXHEAP_H_