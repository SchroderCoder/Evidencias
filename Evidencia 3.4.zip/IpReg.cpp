#include "IpReg.h"


// Constructor vacio de un nuevo objeto del tipo IpReg.
IpReg::IpReg(){
  ip = "";
  ipBase = 0;
  counter = 0;
}


/*
 * Método IpReg:
 * Descripción: Genera un objeto del tipo IpReg con sus variables tomando los valores recibidos en los parametros.
 * Entrada: string 'ipI' que es la direccion ip en formato "v1.v2.v3.v4";
 *          unsigned int 'ipBaseI' que es el valor de la ip de base 256 en base decimal;
 *          int 'counterI' que es la cantidad de veces que aparece cada ip.
 * Salida: Ninguna
 * Precondición: string 'ipI' debe de estar en el formato "v1.v2.v3.v4".
 *               'ipBase' debe ser un unsigned int.
 *               'counterI' debe ser un int.
 * Postcondición: Se genera un nuevo registro con los datos obtenidos.
 * Complejidad: O(1)
*/

IpReg::IpReg(string ipI, unsigned int ipBaseI, int counterI){
  ip = ipI;
  ipBase = ipBaseI;
  counter = counterI;
}


// Destructor del objeto IpReg.
IpReg::~IpReg(){
  
}


/*
 * Método Sobrecarga de '==':
 * Descripción: Sobre carga el operador '==' para saber si la variable 'counter' de dos registros es igual.
 * Entrada: Dos registros.
 * Salida: Valor booleano del resultado de la comparacion realizada entre las variables 'counter' de cada registro.
 * Precondición: Dos registros con variables 'counter' validas.
 * Postcondición: Valor booleano sobre si son o no iguales las variables 'counter'.
 * Complejidad: O(1)
*/

bool IpReg::operator==(const IpReg &other) {
  return this->counter == other.counter;
}


/*
 * Método Sobrecarga de '!=':
 * Descripción: Sobre carga el operador '!=' para saber si la variable 'counter' de dos registros es distinta.
 * Entrada: Dos registros.
 * Salida: Valor booleano del resultado de la comparacion realizada entre las variables 'counter' de cada registro.
 * Precondición: Dos registros con variables 'counter' validas.
 * Postcondición: Valor booleano sobre si son o no distintas las variables 'counter'.
 * Complejidad: O(1)
*/

bool IpReg::operator!=(const IpReg &other) {
  return this->counter != other.counter;
}


/*
 * Método Sobrecarga de '>':
 * Descripción: Sobre carga el operador '>' para saber si la variable 'counter' del primer registro es mayor que la del segundo.
 * Entrada: Dos registros.
 * Salida: Valor booleano del resultado de la comparacion realizada entre las variables 'counter' de cada registro.
 * Precondición: Dos registros con variables 'counter' validas.
 * Postcondición: Valor booleano sobre si la variable 'counter' del primer registro es mayor que la del segundo.
 * Complejidad: O(1)
*/

bool IpReg::operator>(const IpReg &other) {
  return this->counter > other.counter;
}


/*
 * Método Sobrecarga de '<':
 * Descripción: Sobre carga el operador '<' para saber si la variable 'counter' del primer registro es menor que la del segundo.
 * Entrada: Dos registros.
 * Salida: Valor booleano del resultado de la comparacion realizada entre las variables 'counter' de cada registro.
 * Precondición: Dos registros con variables 'counter' validas.
 * Postcondición: Valor booleano sobre si la variable 'counter' del primer registro es menor que la del segundo.
 * Complejidad: O(1)
*/

bool IpReg::operator<(const IpReg &other) {
  return this->counter < other.counter;
}


/*
 * Método Sobrecarga de '<=':
 * Descripción: Sobre carga el operador '<=' para saber si la variable 'counter' del primer registro es menor o igual que la del segundo.
 * Entrada: Dos registros.
 * Salida: Valor booleano del resultado de la comparacion realizada entre las variables 'counter' de cada registro.
 * Precondición: Dos registros con variables 'counter' validas.
 * Postcondición: Valor booleano sobre si la variable 'counter' del primer registro es menor o igual que la del segundo.
 * Complejidad: O(1)
*/

bool IpReg::operator<=(const IpReg &other) {
  return this->counter <= other.counter;
}


/*
 * Método Sobrecarga de '>=':
 * Descripción: Sobre carga el operador '>=' para saber si la variable 'counter' del primer registro es mayor o igual que la del segundo.
 * Entrada: Dos registros.
 * Salida: Valor booleano del resultado de la comparacion realizada entre las variables 'counter' de cada registro.
 * Precondición: Dos registros con variables 'counter' validas.
 * Postcondición: Valor booleano sobre si la variable 'counter' del primer registro es mayor o igual que la del segundo.
 * Complejidad: O(1)
*/

bool IpReg::operator>=(const IpReg &other) {
  return this->counter >= other.counter;
}


/*
 * Método Sobrecarga de '<<':
 * Descripción: Sobre carga el operador '<<' para generar y devolver un string con todos los datos de cada registro.
 * Entrada: Un Registro valido.
 * Salida: String con la ip y numero de ingresos de cada registro. Ejemplo: ip: 142.248.253.242 ----- ingresos: 15
 * Precondición: Tener un registro valido con ip y contador.
 * Postcondición: string con los datos del registro.
 * Complejidad: O(1)
*/

ostream& operator<<(ostream& os, const IpReg& ipReg)
{
  string registro;
  registro += "ip: " + ipReg.ip + " ----- ";
  registro += "ingresos: " + std::to_string(ipReg.counter);
  os << registro;
  return os;
}