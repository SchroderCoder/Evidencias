#ifndef _BITACORA_H_
#define _BITACORA_H_

#include <iostream>
#include <fstream>
#include <string>
#include <vector>

#include "Registro.h"

using std::string;
using std::ifstream;
using std::cin;
using std::cout;
using std::ofstream;
using std::endl;
using std::vector;

// Clase para los registros.
class Bitacora{

  public:
    // Constructor que recibe como entrada: string 'filename' que es el nombre del archivo de la bitacora. Debe ser un archivo .txt
    Bitacora(string filenameI);
    // Destructor de Bitacora.
    ~Bitacora();

    // Carga los registros del archivo a la bitacora.
    void loadRegistros();
    // Muestra al usuario todos los registros de la bitacora.
    void showAllRegistros();
    // Muestra al usuario los registros del intervalo de fechas proporcionado.
    void showRegistros();
    // Genera un archivo con los registros de la bitacora con el nombre que recibe como parametro en formato "nombre.txt".
    void generateBitacoraFile(string filenameO);

    /*
     * Metodos para el ordenamiento:
     *   void 'merge': Fusiona los elementos de dos arreglos con un orden ascendente.
     *   void 'mergeSort': Ordena de forma ascendente los datos por el método de ordenamiento por fusión (merge)
     *   void 'sortMerge': Llama al metodo 'mergeSort' para ordenar los registros de la bitacora.
    */
    void merge(int low, int m, int high);
    void mergeSort(int low, int high);
    void sortMerge();

    /*
     * Metodos para el ordenamiento:
     *   int 'partition': Genera las particiones a utilizar con el pivote.
     *   void 'quickSort': Ordena de forma ascendente los datos por el método de ordenamiento por Quick Sort.
     *   void 'sortQuick': Llama al metodo 'quickSort' para ordenar los registros de la bitacora.
    */
    int partition(int low, int high);
    void quickSort(int low, int high);
    void sortQuick();

    // Registra la fecha de inicio del intervalo de busqueda.
    void registroFechaInicio(string fechaInicio);
    // Registra la fecha de fin del intervalo de busqueda.
    void registroFechaFinal(string fechaFinal);
    // Realiza una busqueda de un registro de la bitacora con el metodo de busqueda binaria.
    int busquedaBinaria(Registro reg);
    // Revisa que las fechas de inicio y fin se encuentren en la bitacora y que sea un intervalo valido.
    void checarFechas();


  private:
    // String que almacena el nombre del archivo .txt
    string filePath;
    // Vector de objetos de tipo Registro que almacena los registros de la bitacora.
    vector<Registro> Registros;
    // Registro con la fecha de inicio que se busca encontrar.
    Registro FechaInicio;
    // Registro con la fecha de inicio que se busca encontrar.
    Registro FechaFinal;
    
    /*
     * Variables que seran parte de cada registro:
     *   Entero 'indexFechaI' para almacenar el indice del registro que cuenta con la fecha inicial en la bitacora.
     *   Entero 'indexFechaF' para almacenar el indice del registro que cuenta con la fecha final en la bitacora.
    */
    int indexFechaI, indexFechaF;
  
};

#endif