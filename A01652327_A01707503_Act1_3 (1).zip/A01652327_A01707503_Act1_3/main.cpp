/*
 * Fecha: 26 Mar 2022
 *
 * Matrícula: A01652327
 * Nombre: Diego Esparza Hurtado
 *
 * Matrícula: A01707503
 * Nombre: Carlos Adrian Garcia Estada
 * 
 * Actividad 1.3 - Actividad Integral de Conceptos Básicos y Algoritmos Fundamentales.
 *
 * El programa consiste en el ordenamiento de una bitacora, busqueda de intervalos de registros para su despliegue.
 *      El programa debe recibir el archivo con los registros a ordenar y genera un archivo nuevo con los registros ordenados.
 *      Realiza la busqueda de dos fechas de registros que el usuario introduce y despliega todos los registros en el intervalo cerrado.
 * 
 * Para compilar: 
 * g++ -std=c++17 *.cpp
 *
 * Para ejecutar:
 * ./a.out
*/

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <chrono>

using std::cin;
using std::cout;

#include "Bitacora.h"

int main() 
{
  // Variable tipos String para almacenar la fecha inicial recibida por el usuario.
  string fechaI;
  // Variable tipos String para almacenar la fecha final recibida por el usuario.
  string fechaF;

  // Se genera un nuevo objeto tipo Bitacora que recibe el nombre del archivo .txt.
	Bitacora bitacora("bitacora.txt");
  
  // Se cargan los registros del archivo .txt solicitado previamente. En caso de no poderse cargar, se arroja un error y termina el programa.
  try{
		bitacora.loadRegistros();
	}
	catch(std::exception const& e){
   	cout << "There was an error: " << e.what() << endl;
    return 0;
 	}
	catch (...){
		cout<<"Error desconocido"<<endl;
    return 0;
	}

  // Inicio conteo de tiempo de ejecución
  //auto startTime = std::chrono::high_resolution_clock::now();
  
  // Se ordenan los registros del objeto bitacora.
  //bitacora.sortMerge();
  bitacora.sortQuick();
  
  // Termina conteo de tiempo de ejecución 
  // auto endTime = std::chrono::high_resolution_clock::now();
  // auto totalTime = endTime - startTime;
  // cout << "Tiempo de ejecución en ms: " << totalTime/std::chrono::milliseconds(1) << endl;

  // Se genera el archivo de salida con los registros en el mismo formato de ingreso, pero ya ordenados con el nombre "bitacora_ordenada.txt".
  bitacora.generateBitacoraFile("bitacora_ordenada.txt");

  // Se solicita al usuario la fecha inicial y se almacena en la variable 'fechaI'.
  cout << "Ingrese la fecha inicial con formato: Mes (Primeras tres letras iniciando con mayúscula) día (doble digito) hora (hora:minuto:segundo). Mes dd hh:mm:ss Ejemplo: Oct 01 14:45:50" << endl;
  getline (cin, fechaI);

  // Se solicita al usuario la fecha final y se almacena en la variable 'fechaF'.
  cout << "Ingrese la fecha final con formato: Mes (Primeras tres letras iniciando con mayúscula) día (doble digito) hora (hora:minuto:segundo). Mes dd hh:mm:ss Ejemplo: Oct 01 14:45:50" << endl;
  getline (cin, fechaF);

  cout << endl;

  // Se pasa a la bitacora la fecha de inicio y final para poder realizar la busqueda.
  bitacora.registroFechaInicio(fechaI);
  bitacora.registroFechaFinal(fechaF);
  
  // Se corrobora que el intervalo de fechas sea valido, en caso de no serlo, será solicitado nuevamente.
  bitacora.checarFechas();

  // Se despliegan los registros 
  bitacora.showRegistros();

  return 0;
}



/* Referencias:
* https://www.w3schools.com/cpp/cpp_files.asp
* https://www.geeksforgeeks.org/substring-in-cpp/
*/