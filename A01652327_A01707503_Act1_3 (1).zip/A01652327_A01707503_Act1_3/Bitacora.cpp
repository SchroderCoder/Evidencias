#include "Bitacora.h"


/*
 * Método Bitacora:
 * Descripción: Genera un objeto del tipo Bitacora con sus variables tomando los valores recibidos en los parametros.
 * Entrada: string 'filenameI' que es el nombre del archivo en formato "nombre.txt"
 * Salida: Ninguna
 * Precondición: Recibir el nombre en formato "nombre.txt".
 * Postcondición: Se genera una nueva Bitacora con el nombre del archivo en la variable 'filePath'.
 * Complejidad: O(1)
*/

Bitacora::Bitacora(string filenameI){

  // Se asigna a la variable filePath el nombre del archivo recibido como parametro de filenameI.
  filePath = filenameI;
}

// Destructor vacio del objeto tipo Bitacora.
Bitacora::~Bitacora(){
  
}

/*
 * Método loadRegistros:
 * Descripción: Lee un archivo y genera los registros con la informacion del mismo. En caso de no poder hacerlo, manda un error.
 * Entrada: Nada
 * Salida: Nada
 * Precondición: Tener un archivo .txt valido con los registros que seran cargados a la bitacora.
 * Postcondición: El vector Registros con los registros generados a partir del archivo.
 * Complejidad: O(n)
*/

void Bitacora::loadRegistros(){
  // Se genera un ifstream 'MyReadFile' con el nombre del archivo previamente almacenado en 'filePath'.
  ifstream MyReadFile(filePath);
  MyReadFile.exceptions ( ifstream::badbit );

  // Se checa si se puede abrir adecuadamente el archivo.
	if(MyReadFile.is_open()){
    string myText;
    
    // Se obtiene cada linea del archivo para obtener la informacion de cada registro.
    while (getline(MyReadFile, myText)){
      
      // Se obtiene el mes:
      string text = myText;
      int pos = text.find(" ");
      string mes = text.substr(0,pos);

      // Se obtiene el día:
      text = text.substr(pos+1);
      pos = text.find(" ");
      string dia = text.substr(0,pos);
  
      // Se obtiene la hora:
      text = text.substr(pos+1);
      pos = text.find(" ");
      string hora = text.substr(0,pos);
  
      // Se obtiene la ip:
      text = text.substr(pos+1);
      pos = text.find(" ");
      string ip = text.substr(0,pos);
  
      // Se obtiene el motivo:
      string motivo = text.substr(pos+1);

      // Se genera el registro:
      Registro reg = Registro(mes, dia, hora, ip, motivo);
      Registros.push_back(reg);
    }
    // Se cierra el archivo.
    MyReadFile.close();
  }
  // En caso de no poder abrir el archivo adecuadamente, se arroja un error.
  else {
    MyReadFile.close();
    throw std::invalid_argument("Error en la lectura de archivo.");
  }
}


/*
 * Método showAllRegistros:
 * Descripción: Despliega en pantalla todos los registros de la bitacora.
 * Entrada: Nada
 * Salida: Imprime todos los registros de la bitacora.
 * Precondición: Qe haya una bitacora con Registros valida.
 * Postcondición: Imprime los registros de la bitacora.
 * Complejidad: O(n)
*/

void Bitacora::showAllRegistros(){
  	for(long unsigned int i=0; i<Registros.size(); i++) {
			cout << Registros[i].getRegistro() << endl;
		}
}


/*
 * Método showRegistros:
 * Descripción: Muestra los registros desde la fecha inicial hasta la fecha final.
 * Entrada: Nada.
 * Salida: Imprime los registros que se encuentren entre la fecha inicial y la fecha final.
 * Precondición: Que haya un intervalo de indices valido y registros en el vector Registros.
 * Postcondición: Imprime los registros dentro del intervalo de fechas.
 * Complejidad: O(n)
*/

void Bitacora::showRegistros(){
  cout << "Resultado: " << indexFechaF-indexFechaI+1 << " Registros" << endl;	
  for(int i=indexFechaI; i<=indexFechaF; i++) {
			cout << Registros[i].getRegistro() << endl;
		}
}


/*
 * Método generateBitacoraFile:
 * Descripción: Genera un archivo .txt donde se almacenan los registros de la bitacora.
 * Entrada: string 'filenameO' que es el nombre del archivo en formato "nombre.txt".
 * Salida: Archivo .txt con los registros de la bitacora, uno por linea.
 * Precondición: Nombre del archivo recibido en formato "nombre.txt" y una bitacora con vector Registros con n Registros.
 * Postcondición: Archivo con nombre "nombre.txt" con los registros de la bitacora.
 * Complejidad: O(n)
*/

void Bitacora::generateBitacoraFile(string filenameO){
  // Se genera un archivo con el nombre recibido como parametro.
  ofstream MyFile(filenameO);
  // Se escribe en cada linea del archivo generado cada registro de la bitacora.
  for(long unsigned int i=0; i<Registros.size(); i++) {
			MyFile << Registros[i].getRegistro() << endl;
	}
}


/*
 * Método merge:
 * Descripción: Fusiona los elementos de dos arreglos con un orden ascendente.
 * Entrada: Entero 'low' que es el límite izquierdo del vector; Entero 'm' que es el punto medio del vector;
 *          Entero 'high' que es el límite derecho del vector.
 * Salida: Nada.
 * Precondición: La bitacora debe de contener un vector Registros coon sus respectivos objetos tipo Registros.
 * Postcondición: El vector Registros con los subarreglos fusionados y con sus valores ordenados de forma ascendente.
 * Complejidad: O(n)
*/

void Bitacora::merge(int low, int m, int high){
  /*
   * Inicializar las variables a utilizar:
   *   Entero 'i' para el índice del primer subarreglo.
   *   Entero 'j' para el índice del segundo subarreglo.
   *   Entero 'k' para el índice del vector.
   *   Entero 'n1' para el tamaño del primer subarreglo.
   *   Entero 'n2' para el tamaño del segundo subarreglo.
  */
  int i, j, k;
  int n1 = m - low + 1;
  int n2 = high - m;
  // Crear los vectores que almacenarán los elementos de los subarreglos.
  vector<Registro> L(n1), R(n2);
  // Copiar los elementos a cada uno de los subarreglos.
  for (i = 0; i < n1; i++)  L[i] = (Registros[low + i]);
  for (j = 0; j < n2; j++)  R[j] = Registros[m + 1 + j];
  // Se fusionan los subarreglos.
  i = j = 0;
  k = low;
  // Se realiza lo que se encuentra dentro del ciclo while mientras el valor de 'i' sea menor a 'n1' y que el valor de 'j' sea menor a 'n2'.
  while (i < n1 && j < n2) {
    // Se revisa si el elemento del primer subarreglo en la posición 'i' es menor o igual al elemento del segundo subarreglo en la posición 'j'.
    if (L[i] <= R[j]){
      // Se almacena el elemento del primer subarreglo en la posición 'i' en el vector 'Registros' en la posición 'k'
      Registros[k] = L[i];
      i = i + 1;
    }
    else {
      // Se almacena el elemento del segundo subarreglo en la posición 'j' en el vector 'Registros' en la posición 'k'
      Registros[k] = R[j];
      j = j + 1;
    }
    k = k + 1;
  }
  // Se copian los elementos restantes del primer subarreglo al vector.
  while (i < n1) {
    // Se almacena el elemento del primer subarreglo en la posición 'i' en el vector 'Registros' en la posición 'k'
    Registros[k] = L[i];
    i = i + 1;
    k = k + 1;
  }
  // Se copian los elementos restantes del segundo subarreglo al vector.
  while (j < n2) {
    // Se almacena el elemento del segundo subarreglo en la posición 'j' en el vector 'Registros' en la posición 'k'
    Registros[k] = R[j];
    j = j + 1;
    k = k + 1;
  }
}


/*
 * Método mergeSort:
 * Descripción: Ordena de forma ascendente los datos por el método de ordenamiento por fusión (merge).
 * Entrada: Entero 'low' que es el límite izquierdo del vector; Entero 'high' que es el límite derecho del vector.
 * Salida: Nada.
 * Precondición: La bitacora debe de contener un vector Registros coon sus respectivos objetos tipo Registros.
 * Postcondición: La bitacora debe de contener los n valores ordenados del vector Registros de forma ascendente.
 * Complejidad: Mejor caso -> O(n log(n)) ; Caso promedio -> O(n log(n))  ; Peor caso -> O(n log(n)) 
*/

void Bitacora::mergeSort(int low, int high){
  // Se revisa si el límite izquierdo es menor al límite derecho.
  if (low < high) {
    // Se encuentra el punto medio del vector y se almacena en el entero 'm'.
    int m = low + (high - low)/2;
    // Se ordenan las dos mitades del vector con el método 'ordenaMerge'.
    mergeSort(low, m);
    mergeSort(m+1, high);
    // Se fusionan ambas mitades con el método 'merge'.
    merge(low, m, high);
  }
}


/*
 * Método sortMerge:
 * Descripción: Llama al metodo mergeSort para ordenar el vector Registros de la Bitacora.
 * Entrada: Nada.
 * Salida: Nada.
 * Precondición: La bitacora debe de contener un vector Registros coon sus respectivos objetos tipo Registros.
 * Postcondición: La bitacora debe de contener los n valores ordenados del vector Registros de forma ascendente.
 * Complejidad: Mejor caso -> O(n log(n)) ; Caso promedio -> O(n log(n))  ; Peor caso -> O(n log(n))
*/

void Bitacora::sortMerge(){
  mergeSort(0, Registros.size()-1);
}


/*
 * Método partition:
 * Descripción: Toma el ultimo elemento como pivote y genera las particiones a utilizar.
 * Entrada: Entero 'low' que es el límite izquierdo del vector; Entero 'high' que es el límite derecho del vector.
 * Salida: variable i+1.
 * Precondición: La bitacora debe de contener un vector Registros coon sus respectivos objetos tipo Registros.
 * Postcondición: Ubica al pivote en su posicion correcta. Ademas, manda a los valores menores a su izquierda y a los mayores mayores a su derecha.
 * Complejidad: O(n)
*/

int Bitacora::partition(int low, int high) {
  Registro pivot = Registros[high];
  int i = low-1;
  for(int j = low; j<high; j++) {
    if(Registros[j] < pivot){
      i++;
      Registro temp = Registros[i];
      Registros[i] = Registros[j];
      Registros[j] = temp;
    }
  }
  Registro temp2 = Registros[i+1];
  Registros[i+1] = Registros[high];
  Registros[high] = temp2;
  return i+1;
}


/*
 * Método quickSort:
 * Descripción: Ordena de forma ascendente los datos por el método de ordenamiento por particiones.
 * Entrada: Entero 'low' que es el límite izquierdo del vector; Entero 'high' que es el límite derecho del vector.
 * Salida: Nada.
 * Precondición: La bitacora debe de contener un vector Registros coon sus respectivos objetos tipo Registros.
 * Postcondición: La bitacora debe de contener los n valores ordenados del vector Registros de forma ascendente.
 * Complejidad: Mejor caso -> O(n log(n)) ; Caso promedio -> O(n log(n))  ; Peor caso -> O(n^2)
*/

void Bitacora::quickSort(int low, int high) {
  if (low < high)  {
    // encontrar pivote de la particion
	  int pi = partition(low, high);
    // ordenar la mitad izquierda y derecha
	  quickSort(low, pi - 1);
	  quickSort(pi + 1, high);
  }
}


/*
 * Método sortQuick:
 * Descripción: Llama al metodo quickSort para ordenar el vector Registros de la Bitacora.
 * Entrada: Nada.
 * Salida: Nada.
 * Precondición: La bitacora debe de contener un vector Registros coon sus respectivos objetos tipo Registros.
 * Postcondición: La bitacora debe de contener los n valores ordenados del vector Registros de forma ascendente.
 * Complejidad: Mejor caso -> O(n log(n)) ; Caso promedio -> O(n log(n))  ; Peor caso -> O(n^2)
*/

void Bitacora::sortQuick(){
  quickSort(0, Registros.size()-1);
}



/*
 * Método registroFechaInicio:
 * Descripción: Genera un objeto del tipo Registro con la fecha inicial a buscar.
 * Entrada: string 'fechaInicio' que recibe en formato: "Mes dd hh:mm:ss"
 * Salida: Nada.
 * Precondición: Que haya una Bitacora valida y que la fecha se encuentre en el formato correcto.
 * Postcondición: Se genera un Registro nuevo con la fecha recibida y con 'ip' y 'motivo' con valor " ".
 * Complejidad: O(1)
*/

void Bitacora::registroFechaInicio(string fechaInicio){

  // Se obtiene el mes:
  string text = fechaInicio;
  int pos = text.find(" ");
  string mes = text.substr(0,pos);

  // Se obtiene el día:
  text = text.substr(pos+1);
  pos = text.find(" ");
  string dia = text.substr(0,pos);
  
  // Se obtiene la hora:
  string hora = text.substr(pos+1);

  // Se obtiene la ip:
  string ip = " ";
  // Se obtiene el motivo:
  string motivo = " ";
  
  // Se genera el registro:
  FechaInicio = Registro(mes, dia, hora, ip, motivo);
}


/*
 * Método registroFechaFinal:
 * Descripción: Genera un objeto del tipo Registro con la fecha final a buscar.
 * Entrada: string 'fechaInicio' que recibe en formato: "Mes dd hh:mm:ss"
 * Salida: Nada.
 * Precondición: Que haya una Bitacora valida y que la fecha se encuentre en el formato correcto.
 * Postcondición: Se genera un Registro nuevo con la fecha recibida y con 'ip' y 'motivo' con valor " ".
 * Complejidad: O(1)
*/

void Bitacora::registroFechaFinal(string fechaFinal){
  // Se obtiene el mes:
  string text = fechaFinal;
  int pos = text.find(" ");
  string mes = text.substr(0,pos);

  // Se obtiene el día:
  text = text.substr(pos+1);
  pos = text.find(" ");
  string dia = text.substr(0,pos);
  
  // Se obtiene la hora:
  string hora = text.substr(pos+1);

  // Se obtiene la ip:
  string ip = " ";
  // Se obtiene el motivo:
  string motivo = " ";
  // Se genera el registro:
  FechaFinal = Registro(mes, dia, hora, ip, motivo);
}


/*
 * Método busquedaBinaria:
 * Descripción: Busca un Registro con un valor de 'date' (fecha) especifico en el vector Registros ordenado de manera ascendente con el método de búsqueda binaria.
 * Entrada: Registro 'reg' que cuenta con la fecha a buscar en el vector Registros.
 * Salida: Índice donde se ubica el valor o -1 en caso de que no se localice.
 * Precondición: La Bitacora debe de contar con un vector Registros con n valores ordenados de forma ascendente.
 * Postcondición: Ninguna.
 * Complejidad: Mejor caso -> O(1) ; Caso promedio -> O(log2(n))  ; Peor caso -> O(log(n)). 
*/

int Bitacora::busquedaBinaria(Registro reg){
  int low = 0;
  int high = Registros.size()-1;
  while (low <= high){
    // Se encuentra el punto medio del vector y se almacena en el entero 'm'.
    int m = low + (high - low)/2;
    // Se revisa si el valor a buscar 'key' es igual al valor en la posición 'm'. En caso de serlo, se devuelve el valor de 'm'.
    if (reg == Registros[m]) return m;
    // En caso de ser distinto, se revisa si el valor a buscar 'key' es menor al valor en la posición 'm'.
    // En caso de serlo, el límite derecho 'high' toma el valor medio 'm' - 1. En caso de no serlo, el límite izquierdo 'low' toma el valor medio 'm' + 1.
    else if (reg < Registros[m]) high = m - 1;
    else low = m + 1;
  }
  // En caso de no encontrar el valor a buscar, se devuelve un -1.
  return -1;
}


/*
 * Método checarFechas:
 * Descripción: Se revisa que la fecha inicial sea menor o igual a la fecha final. De igual manera, se corrobora que ambas fechas se encuentren en algun Registro; en caso de no ser así, se le notifica al usuario y se le piden nuevas fechas.
 * Entrada: Nada como parametros. Dentro se le pueden llegar a solicitar fechas al usuario en formato "Mes dd hh:mm:ss".
 * Salida: Nada.
 * Precondición: Una Bitacora con un vector de Registros y 
 * Postcondición:
 * Complejidad: Mejor caso -> O(1); Peor caso -> O(nlog(n)). El peor caso considera n intentos del usuario y el peor caso en la busqueda binaria.
*/

void Bitacora::checarFechas(){

  // Se revisa si el Registro FechaInicio cuenta con un valor en la variable 'date' menor o igual a la variable 'date' del Registro FechaFinal.
  // En caso de no cumplir con la condicion, se pide al usuario que ingrese nuevamente las fechas inicial y final para generar los Registros y volver a checar las fechas.
  if (FechaInicio <= FechaFinal){

    // Se almacenan los resultados de la busqueda binaria de cada una de las fechas (inicial y final) en las variables 'indexFechaI', 'indexFechaF'.
    indexFechaI = busquedaBinaria(FechaInicio);
    indexFechaF = busquedaBinaria(FechaFinal);

    // Se revisa si se encontro algun registro con la fecha inicial.
    // En caso de no haber encontrado un registro, se solicita una nueva fecha inicial, se genera un registro con la fecha y se comprueban nuevamente las fechas.
    if (indexFechaI == -1){
      cout << "Lo sentimos, fecha inicial invalida, ingrese nueva fecha:" << endl;
      string fechaI;
      getline (cin, fechaI);
      registroFechaInicio(fechaI);
      checarFechas();
    }

    // Se revisa si se encontro algun registro con la fecha final.
    // En caso de no haber encontrado un registro, se solicita una nueva fecha final, se genera un registro con la fecha y se comprueban nuevamente las fechas.
    if (indexFechaF == -1){
      cout << "Lo sentimos, fecha final invalida, ingrese nueva fecha:" << endl;
      string fechaF;
      getline (cin, fechaF);
      registroFechaFinal(fechaF);
      checarFechas();
    }

    cout << endl; 

  }
  else{
    // Se solicitan al usuario las fechas inicial y final.
    cout << "Lo sentimos, rango de fechas invalida, ingrese nuevas fechas: " << endl;
    string fechaI;
    string fechaF;
    cout << "Ingrese nueva fecha inicial:" << endl;
    getline (cin, fechaI);
    cout << "Ingrese nueva fecha final:" << endl;
    getline (cin, fechaF);
    // Se generan los nuevos registros con las fechas nuevas.
    registroFechaInicio(fechaI);
    registroFechaFinal(fechaF);
    // Se revisa si las fechas son validas.
    checarFechas();
  }
  
}