#include "Registro.h"


// Constructor vacio de un nuevo objeto del tipo Registro.
Registro::Registro() {
  
}


/*
 * Método Registro:
 * Descripción: Genera un objeto del tipo Registro con sus variables tomando los valores recibidos en los parametros.
 * Entrada: string 'mesI' que es el mes en formato "Ene"; string 'diaI' que es el dia en formato "dd";
 *          string 'horaI' que es la hora en formato "hh:mm:ss"; string 'ipI' que es la direccion ip;
 *          string 'motivoI' que es el motivo del registro.
 * Salida: Ninguna
 * Precondición: Todas las variables debe ser del tipo string.
 *               'mesI' debe de estar en el formato "Mes"; 'diaI' en formato "dd"; 'horaI' en formato "hh:mm:ss";
 * Postcondición: Se genera un nuevo registro con los datos obtenidos.
 * Complejidad: O(1) por ser constante la cantidad de meses en 12.
*/

Registro::Registro(string mesI, string diaI, string horaI, string ipI, string motivoI){

  // Se copian los valores recibidos como parametros a las variables del registro.
  mes = mesI;
  diaT = diaI;
  // Se realiza la conversion del dia de un string a un entero.
  dia = std::stoi(diaI);
  horaT = horaI;
  ip = ipI;
  motivo = motivoI;

  // Se separa la hora de formato hh:mm:ss para almacenar en cada variable de hora, minuto y segundo.
  int pos = horaI.find(":");
  // Se almacena la hora en formato de entero.
  hora = std::stoi(horaI.substr(0,pos));

  horaI = horaI.substr(pos+1);
  pos = horaI.find(":");
  // Se almacena el minuto en formato de entero.
  minuto = std::stoi(horaI.substr(0,pos));

  // Se almacena el segundo en formato de entero.
  segundo = std::stoi(horaI.substr(pos+1));

  // Se genera la estructura de fecha con el mes, dia, hora, minuto, segundo.
  dateStruct.tm_sec = segundo;
  dateStruct.tm_min = minuto;
  dateStruct.tm_hour = hora;
  dateStruct.tm_mday = dia;
  // Agregado para resolver problema de compatibilidad en Windows
  dateStruct.tm_isdst = 0;
  for (long unsigned int i=0; i < meses.size(); i++) {
    if (meses[i]==mes)
      dateStruct.tm_mon = i;
  }
  dateStruct.tm_year = 2022 - 1900;  // Asumimos el año 2022
  // Obtener el Unix timestamp a partir del struct tm anterior 
  date = mktime(&dateStruct);
  
}

// Destrutor del r¡objeto registro.
Registro::~Registro(){
  
}


/*
 * Método getRegistro:
 * Descripción: Genera y devuelve un string con todos los datos de cada registro para devolverlos.
 * Entrada: Nada.
 * Salida: String con el mes, dia hora, ip y motivo de cada registro. Ejemplo: Jul 09 16:19:58 142.248.253.242:2871 Illegal user
 * Precondición: Tener un registro valido con mes, dia, hora, ip y motivo.
 * Postcondición: string con los datos del registro.
 * Complejidad: O(1)
*/

string Registro::getRegistro(){
  string registro;
  registro += mes + " ";
  registro += diaT + " ";
  registro += horaT + " ";
  registro += ip + " ";
  registro += motivo;
  return registro;
}


/*
 * Método getDate:
 * Descripción: Devuelve el valor de la variable 'date' del registro.
 * Entrada: Nada
 * Salida: Valor de la variable 'date' del registro.
 * Precondición: Tener un registro valido que cuente con su respectivo valor 'date'.
 * Postcondición: obtener el valor de la variable 'date'.
 * Complejidad: O(1)
*/

time_t Registro::getDate() {
  return date;
}


/*
 * Método Sobrecarga de '==':
 * Descripción: Sobre carga el operador '==' para saber si la variable 'date' de dos registros es igual.
 * Entrada: Dos registros.
 * Salida: Valor booleano del resultado de la comparacion realizada entre las variables 'date' de cada registro.
 * Precondición: Dos registros con variables 'date' validas.
 * Postcondición: Valor booleano sobre si son o no iguales las variables 'date'.
 * Complejidad: O(1)
*/

bool Registro::operator==(const Registro &other) {
  return this->date == other.date;
}


/*
 * Método Sobrecarga de '!=':
 * Descripción: Sobre carga el operador '!=' para saber si la variable 'date' de dos registros es distinta.
 * Entrada: Dos registros.
 * Salida: Valor booleano del resultado de la comparacion realizada entre las variables 'date' de cada registro.
 * Precondición: Dos registros con variables 'date' validas.
 * Postcondición: Valor booleano sobre si son o no distintas las variables 'date'.
 * Complejidad: O(1)
*/

bool Registro::operator!=(const Registro &other) {
  return this->date != other.date;
}


/*
 * Método Sobrecarga de '>':
 * Descripción: Sobre carga el operador '>' para saber si la variable 'date' del primer registro es mayor que la del segundo.
 * Entrada: Dos registros.
 * Salida: Valor booleano del resultado de la comparacion realizada entre las variables 'date' de cada registro.
 * Precondición: Dos registros con variables 'date' validas.
 * Postcondición: Valor booleano sobre si la variable 'date' del primer registro es mayor que la del segundo.
 * Complejidad: O(1)
*/

bool Registro::operator>(const Registro &other) {
  return this->date > other.date;
}


/*
 * Método Sobrecarga de '<':
 * Descripción: Sobre carga el operador '<' para saber si la variable 'date' del primer registro es menor que la del segundo.
 * Entrada: Dos registros.
 * Salida: Valor booleano del resultado de la comparacion realizada entre las variables 'date' de cada registro.
 * Precondición: Dos registros con variables 'date' validas.
 * Postcondición: Valor booleano sobre si la variable 'date' del primer registro es menor que la del segundo.
 * Complejidad: O(1)
*/

bool Registro::operator<(const Registro &other) {
  return this->date < other.date;
}


/*
 * Método Sobrecarga de '<=':
 * Descripción: Sobre carga el operador '<=' para saber si la variable 'date' del primer registro es menor o igual que la del segundo.
 * Entrada: Dos registros.
 * Salida: Valor booleano del resultado de la comparacion realizada entre las variables 'date' de cada registro.
 * Precondición: Dos registros con variables 'date' validas.
 * Postcondición: Valor booleano sobre si la variable 'date' del primer registro es menor o igual que la del segundo.
 * Complejidad: O(1)
*/

bool Registro::operator<=(const Registro &other) {
  return this->date <= other.date;
}


/*
 * Método Sobrecarga de '>=':
 * Descripción: Sobre carga el operador '>=' para saber si la variable 'date' del primer registro es mayor o igual que la del segundo.
 * Entrada: Dos registros.
 * Salida: Valor booleano del resultado de la comparacion realizada entre las variables 'date' de cada registro.
 * Precondición: Dos registros con variables 'date' validas.
 * Postcondición: Valor booleano sobre si la variable 'date' del primer registro es mayor o igual que la del segundo.
 * Complejidad: O(1)
*/

bool Registro::operator>=(const Registro &other) {
  return this->date >= other.date;
}