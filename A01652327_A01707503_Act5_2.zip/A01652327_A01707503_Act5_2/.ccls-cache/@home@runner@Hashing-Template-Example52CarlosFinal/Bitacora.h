#ifndef _BITACORA_H_
#define _BITACORA_H_

#include <iostream>
#include <fstream>
#include <string>
#include <vector>

#include "Graph.h"
#include "HashTable.h"

// 20%
//# define SIZE 16057
// Num colisiones: 5511

// 30%
//# define SIZE 17383
// Num colisiones: 5110

// 50%
//# define SIZE 20063
// Num colisiones: 4470

// 100%
# define SIZE 26759
// Num colisiones: 3326

// Clase para obtener los registros y realizar todo el proceso necesario.
 class Bitacora{

  public:
  	// Constructor que recibe como entrada: string 'filename' que es el nombre del archivo de la bitacora. Debe ser un archivo .txt
    Bitacora(std::string filename);
    // Destructor de Bitacora.
    ~Bitacora();

    void getIPSummary(std::string ipUsuarioEntrada);


  private:

    Graph Grafo;
    HashTable<unsigned int, IpReg> Tabla;

    vector<IpReg> Registros;
    vector<std::string> Conexiones;
  
};

#endif