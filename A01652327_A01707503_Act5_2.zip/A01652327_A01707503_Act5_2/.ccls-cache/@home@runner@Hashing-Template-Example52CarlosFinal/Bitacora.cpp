 #include "Bitacora.h"

Bitacora::Bitacora(std::string filename){
  Grafo.loadDirectedGraph(filename);
  Tabla.setCapacity(SIZE);
  
  Grafo.generateIPSummary();
  Registros = Grafo.getRegistros();

  for (int i=0; i<Registros.size(); i++){
    Tabla.add(Registros[i].getIpDecimal(),Registros[i]);
  }

  //Tabla.print();

  std::cout << "Numero de colisiones: " << Tabla.getCounterColisiones() << std::endl;

}

Bitacora::~Bitacora(){
  
}

void Bitacora::getIPSummary(std::string ipUsuarioEntrada){
  
  std::string ipUsuario = ipUsuarioEntrada;
  IpReg tmpIP(ipUsuario, 0, 0);

  int index = Tabla.find(tmpIP.getIpDecimal());

  std::cout << std::endl;
  std::cout << "Result index: " << index << std::endl;
  if (index == -1)
    std::cout << "\tElement not found" << std::endl;
  else{
    std::cout << "\tData: " << Tabla.getDataAt(index) << std::endl;
    Conexiones = Grafo.getConexiones(ipUsuario);
    std::cout << "Conexiones accesadas: " << std::endl;
    for (int i=0; i<Conexiones.size(); i++)
      std::cout << i+1 << ": "<< Conexiones[i] << std::endl;
    std::cout << std::endl;
  }

  
/*
  240.64.152.165

  73.89.221.25
*/
}