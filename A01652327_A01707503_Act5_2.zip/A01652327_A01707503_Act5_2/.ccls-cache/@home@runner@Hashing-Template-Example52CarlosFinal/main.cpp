/*
 * Fecha: 3 de junio 2022
 *
 * Matrícula: A01652327
 * Nombre: Diego Esparza Hurtado
 *
 * Matrícula: A01707503
 * Nombre: Carlos Adrián García Estrada
 * 
 * Act 4.3 - Actividad Integral de Grafos
 *
 *El programa cuenta con la implementacion del grafo, el cual es de listas adyacentes. 
 *      El programa obtiene el numero de grados de salida de cada IP para obtener las cinco con mas salidas.
 *      Además, se calcula la ip boot master (mayor numero de salidas) y la distancia minima desde este hacia todos los nodos para calcular la ip mas dificil de alcanzar.
 *
 * Compilacion para debug:  
 *    g++ -std=c++17 -g -o main *.cpp
 * Ejecucion con valgrind:
 *    nix-env -iA nixpkgs.valgrind
 *    valgrind --leak-check=full ./main
 *
 * Compilacion para ejecucion:
 *    g++ -std=c++17 -O3 -o main *.cpp
 * Ejecucion:
 *    ./main
*/

#include <iostream>
#include <sstream>
#include "Bitacora.h"

int main() {
  std::cout << "Lectura:" << std::endl;
  // Recibe la informacion del grafo.

  Bitacora bitacora("bitacoraGrafos.txt");

  std::string ipUsuario;
  std::cout << "Ingresa una ip:" << std::endl;
  std::cin >> ipUsuario;
  bitacora.getIPSummary(ipUsuario);








  
  return 0;
} 

// Referencias:

// GeeksforGeeks. (2022). Dijkstra’s Shortest Path Algorithm using priority_queue of STL. Recuperado el 1 de mayo de 2022. Sitio web: https://www.geeksforgeeks.org/dijkstras-shortest-path-algorithm-using-priority_queue-stl/