#include "Graph.h"

// Constructor vacio.
Graph::Graph(){
  numNodes = 0;
  numEdges = 0;
}


// Destructor del grafo. 
//Complejidad O(V).
//    V = numNodes. 
Graph::~Graph() {
  adjList.clear();
  ips.clear();
}



/*
 * Método loadDirectedGraph:
 * Descripción: Cargue un grafo dirigido ponderado a partir de un archivo empleando la representación en memoria de una Lista de Adyacencia.
 * Entrada: Un string del nombre del archivo en formato .txt que contiene los datos del grafo dirigido ponderado.
 * Salida: Ninguna.
 * Precondición: El archivo pasado por la línea de comandos existe y contiene un grafo dirigido ponderado.
 * Postcondición: Nada.
 * Complejidad: O(V+(E log(V))) Lista de Adyacencia. Esto se debe porque en cada arista se debe de hacer un .find() que tiene complejidad log(n), donde el map es de tamaño V.
 *      V = numNodes.
 *      E = numEdges.
*/

void Graph::loadDirectedGraph(std::string filename) {

  std::ifstream MyReadFile(filename);
  
  std::string line;
  int i = 0;
  while (std::getline(MyReadFile, line)) {
    if (i == 0) {
      std::vector<std::string> res;
      split(line, res);

      // Se recupera el numero de nodos.
      numNodes = stoi(res[0]);

      // Se recupera el numero de aristas.
      numEdges = stoi(res[1]);

      // Reservar memoria para los renglones de la lista de adyacencia (renglon 0 no utilizado).
      adjList.resize(numNodes+1);

      // Declara una lista vacia para cada renglon y la almacena en el vector.
      for (int k = 1; k <= numNodes; k++) {
        LinkedList<std::pair<std::string,int>> tmpList;
        adjList[k] = tmpList;
      }
      i++;
    }
    // Se recuperan las ip y se genera un mapa para asignarle a cada ip un indice comenzando en 1.
    else if (i > 0 && i<=numNodes) {
      ips.insert(std::pair<std::string,int>(line, i));
      // El primer elemento de cada lista sera la ip misma con peso de 0.
      adjList[i].addLast(std::make_pair(line, 0));
      i++;
    }
    // Se recuperan las direcciones de origen y destino con el peso de cada uno de los registros.
    else if (i > numNodes && i <= numNodes+numEdges){
      std::vector<std::string> res;
      split(line, res);

      // Se recupera la ip origen.
      std::string u = res[3];

      // Se recupera la ip destino.
      std::string v = res[4];

      // Se recupera el peso.
      int w = stoi(res[5]);
      
      // Se eliminan los puertos de cada ip.
      int pos = u.find(":");
      u = u.substr(0,pos);
      pos = v.find(":");
      v = v.substr(0,pos);

      //Recuperar el index de la ip origen en el map.
      int index = ips.find(u)->second;

      // Grafos dirigidos agrega aristas con peso (u,v,w)
      adjList[index].addLast(std::make_pair(v,w));

      //Recuperar el index de la ip destino en el map.
      int indexIP = ips.find(v)->second;

      // Se actualiza el contador de conexiones recibidas.
      LLNode<std::pair<std::string,int>> *p = adjList[indexIP].getHead();
      p->data.second = p->data.second+1;
      
      i++;
    }
  }
}


/*
 * Método split:
 * Descripción: Recibe y separa un string por " " para devolver un vector con cada elemento separado.
 * Entrada: Un string 'line' y un vector de strings 'res'.
 * Salida: Ninguna.
 * Precondición: Un string valido y vector validos.
 * Postcondición: El vector con los elementos del string que se encuentren separados por un " ".
 * Complejidad: O(n) Donde 'n' es la cantidad de elementos separados por un " " en el string.
*/

void Graph::split(std::string line, std::vector<std::string> & res) {
  size_t strPos = line.find(" ");
  size_t lastPos = 0;
  while (strPos != std::string::npos) {
    res.push_back(line.substr(lastPos, strPos - lastPos));
    lastPos = strPos + 1;
    strPos = line.find(" ", lastPos);
  }
  res.push_back(line.substr(lastPos, line.size() - lastPos));
}


/*
 * Método printAdjList:
 * Descripción: Despliega en pantalla los elementos del grafo (Listas de adyacencia con sus respectivos elementos).
 * Entrada: Ninguna.
 * Salida: Las listas de adyacencia con sus respectivos elementos.
 * Precondición: Un grafo con listas de adyacencias valido.
 * Postcondición: La impresion de las listas de adyacencia con sus respectivos elementos.
 * Complejidad: O(V+E) Lista de Adyacencia.
 *      V = numNodes.
 *      E = numEdges
*/


void Graph::printAdjList(){
	std::cout << "Adjacency List (node weight)" << std::endl;
	for (int i = 1; i <= numNodes; i++){
    std::cout << "vertex " << i << ": ";
    LLNode<std::pair<std::string,int>> *p = adjList[i].getHead();
    while (p != nullptr){
      std::cout << "(" << p->data.first << " " << p->data.second << ")";
      p = p->next;
    }
    std::cout << std::endl;
  }
  std::cout << std::endl;
}


/*
 * Método printGraph:
 * Descripción: Despliega en pantalla los elementos del grafo (Listas de adyacencia con sus respectivos elementos).
 * Entrada: Ninguna.
 * Salida: Las listas de adyacencia con sus respectivos elementos.
 * Precondición: Un grafo con listas de adyacencias valido.
 * Postcondición: La impresion de las listas de adyacencia con sus respectivos elementos.
 * Complejidad: O(V+E) Lista de Adyacencia.
 *      V = numNodes.
 *      E = numEdges
*/

void Graph::printGraph() {
  printAdjList();
}


/*
 * Método generateIPSummary:
 * Descripción: Se genera un vector Registros con objetos IpReg que cuentan con cada IP, su valor en base decimal, asi como los grados de entrada y salida de cada IP.
 * Entrada: Ninguna.
 * Salida: Ninguna.
 * Precondición: Un grafo valido en memoria.
 * Postcondición: Un vector de Registros valido con el resumen de cada IP.
 * Complejidad: O(V).
 *      V = numNodes.
*/

void Graph::generateIPSummary(){

  std::string ipTemp;
  int entradasTemp;
  int salidasTemp;

  // Se generan los objetos Reg con las caracteristicas de cada IP.
  for (int i = 1; i<=numNodes; i++){
    // Se obtiene la lista de adyacencia de cada Nodo.
    LLNode<std::pair<std::string,int>> *p = adjList[i].getHead();
    // Se recupera la IP.
    ipTemp = p->data.first;
    // Se recupera la cantidad de entradas a dicha IP.
    entradasTemp = p->data.second;
    // Se recupera la cantidad de salidas desde dicha IP.
    salidasTemp = adjList[i].getNumElements()-1;

    // Se genera un Registros IpReg con cada IP.
    IpReg reg = IpReg(ipTemp, entradasTemp, salidasTemp);
    // Se inserta al vector Registros cada objeto IpReg.
    Registros.push_back(reg);
  }  
}


/*
 * Método getRegistros:
 * Descripción: Regresa un vector con la informacion de cada IP (string, valor decimal, numero de entradas y salidas).
 * Entrada: Ninguna.
 * Salida: Regresa el vector Registros.
 * Precondición: Un grafo y vector Registros validos.
 * Postcondición: Se regresa correctamente el vector Registros.
 * Complejidad: O(1)
*/

vector<IpReg>& Graph::getRegistros(){
  return Registros;
}


/*
 * Método checarIp:
 * Descripción: Regresa un valor booleano.
 * Entrada: string 'ipEntrada' que es la IP a corroborar.
 * Salida: Regresa un valor booleano de 'true' or 'false'.
 * Precondición: Un grafo y un string valido.
 * Postcondición: Se revisa si el string se encuentra en el map.
 * Complejidad: O(log(V))
 *      V = numNodes.
*/

bool Graph::checkIp(std::string ipEntrada){
  std::map<std::string,int>::iterator it;
  it = ips.find(ipEntrada);  
  if (it != ips.end())
    return true;
  else 
     return false;  
}


/*
 * Método getConexiones:
 * Descripción: Generar y regresa un vector con los strings de cada IP con conexion entrante desde la IP ingresada.
 * Entrada: string 'ipTemp' que es la IP en formato string de la que se quieren recuperar las IPs de las conexiones realizadas desde dicha IP.
 * Salida: Regresa el vector Conexiones.
 * Precondición: Un string 'ipTemp' valido que se encuentre en el grafo, asi como un grafo y vector Conexiones validos.
 * Postcondición: Se regresa correctamente el vector Conexiones.
 * Complejidad: O(log(V) + 3E + E log(E)) -> aprox -> O(log(V) + E log(E))
 *      V = numNodes.
 *      E = numero de aristas que salen desde la IP recibida.
*/

vector<std::string>& Graph::getConexiones(std::string ipTemp){
  // Se recupera el indice en el grafo de la IP ingresada.
  int index = ips.find(ipTemp)->second;

  // Se genera un vector temporal.
  std::vector<IpReg> vectorTemp;

  // Se recupera el primer elemento de la lista de adyacencia de dicha IP.
  LLNode<std::pair<std::string,int>> *p = adjList[index].getHead();

  // Se recupera la primera conexion saliente.
  p = p->next;

  // Se recupera y genera un registros IpReg con cada una de las conexiones salientes.
  while(p != nullptr){
    IpReg reg = IpReg(p->data.first, 0, 0);
    vectorTemp.push_back(reg);
    p = p->next;
  }

  // Se ordena el vector con el valor de cada IP decimal por la sobrecarga de operadores en la clase IpReg.
  std::sort(vectorTemp.begin(),vectorTemp.end());

  // Se copian unicamente los strings de IP de cada conexion saliente.
  for (int i = 0; i<vectorTemp.size(); i++){
		Conexiones.push_back(vectorTemp[i].getIp());
	}

  // Se limpia el vector temporal.
  vectorTemp.clear();

  // Se devuelve el vector con las conexiones.
  return Conexiones;
}