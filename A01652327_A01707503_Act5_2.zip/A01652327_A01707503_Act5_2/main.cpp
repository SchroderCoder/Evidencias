/*
 * Fecha: 17 de junio 2022
 *
 * Matrícula: A01652327
 * Nombre: Diego Esparza Hurtado
 *
 * Matrícula: A01707503
 * Nombre: Carlos Adrián García Estrada
 * 
 * Act 5.2 - Actividad Integral sobre el uso de codigos hash.
 *
 *El programa cuenta con la implementacion un grafo, el cual es de listas adyacentes. 
 *      El programa obtiene el numero de grados de entrada y salida de cada IP.
 *      Se obtiene una Tabla Hash con el metodo de direccion abierta con prueba cuadratica.
 *      La llave de cada elemento es la IP en formato decimal y el contenido de cada entrada es un objeto con cada IP y sus grados tanto de entrada como de salida.
 *      Se solicita al usuario una IP, se valida su existencia y se imprime su informacion junto con las IPs a las que accedio ordenadas de forma ascendente.
 *
 * Compilacion para debug:  
 *    g++ -std=c++17 -g -o main *.cpp
 * Ejecucion con valgrind:
 *    nix-env -iA nixpkgs.valgrind
 *    valgrind --leak-check=full ./main
 *
 * Compilacion para ejecucion:
 *    g++ -std=c++17 -O3 -o main *.cpp
 * Ejecucion:
 *    ./main
*/

#include <iostream>
#include <sstream>
#include "Bitacora.h"

int main() {

  std::cout << "Lectura:" << std::endl;

  // Se genera una bitacora con la informacion recibida de un archivo txt.
  Bitacora bitacora("bitacoraGrafos.txt");

  // Se solicita al usuario una direccion IP.
  std::string ipUsuario;
  std::cout << "Ingresa una ip:" << std::endl;
  std::cin >> ipUsuario;

  // IP Prueba: 73.89.221.25

  // Se obtiene el resumen de informacion de la IP solicitada por el usuario.
  bitacora.getIPSummary(ipUsuario);


  return 0;
} 