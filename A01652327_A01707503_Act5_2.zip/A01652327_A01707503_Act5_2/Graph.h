#ifndef __GRAPH_H_
#define __GRAPH_H_
#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <queue>
#include <map>
#include <algorithm>
#include "LinkedList.h"
#include "IpReg.h"

// Clase para el objeto grafo.
class Graph {

  private:
    // Entero que es el numero de nodos del grafo.
    int numNodes;
    // Entero que es el numero de aristas del grafo.
    int numEdges;
    // Lista de adyacencia (vector de listas de pares)
    std::vector<LinkedList<std::pair<std::string,int>>> adjList;

    // map con las IPs y su indice unico.
    std::map<std::string,int> ips;

    // Vector de objetos de tipo Registro que almacena los registros de la bitacora.
    vector<IpReg> Registros;

    // Vector de strings que almacena las conexiones salientes desde una IP.
    vector<std::string> Conexiones;

    
    // Metodo para separar una linea string.
    void split(std::string line, std::vector<std::string> & res);

    // Metodo para imprimir el grafo con sus listas de adyacencia.
    void printAdjList();

  
  public:
    // Constructor vacio.
    Graph();
    // Destructor del grafo.
    ~Graph();

    // Metodo para cargar los datos hacia el grafo.
    void loadDirectedGraph(std::string filename);

    // Metodo para imprimir el grafo con sus listas de adyacencia.
    void printGraph();

    // Metodo para generar el vector Registros con la informacion de cada IP (numero de entradas y salidas).
    void generateIPSummary();

    // Metodo que devuelve un valor booleano para revisar si existe o no una IP en el grafo.
    bool checkIp(std::string ipEntrada);

    // Metodo que devuelve el vector de Registros.
    vector<IpReg>& getRegistros();

    // Metodo que genera y devuelve el vector de Conexiones.
    vector<std::string>& getConexiones(std::string ipTemp);

};


#endif // __GRAPH_H_