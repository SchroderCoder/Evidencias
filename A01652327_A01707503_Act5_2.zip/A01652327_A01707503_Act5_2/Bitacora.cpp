 #include "Bitacora.h"


/* 
 * Método Bitacora:
 * Descripción: Se genera una bitacora con su grafo y tabla hash con la informacion de las IPs.
 * Entrada: Un string del nombre del archivo en formato .txt que contiene los datos.
 * Salida: Se imprime el numero de colisiones.
 * Precondición: El archivo pasado por la línea de comandos existe y contiene un grafo dirigido ponderado.
 * Postcondición: Un objeto Bitacora valido.
 * Complejidad: O((V+E log(V)) + (V+E) + V) -> O(3V + E (log(V)+1)) -> aprox -> O(V + E log(V))
 *      V = numIPs.
 *      E = numConexiones.
*/

Bitacora::Bitacora(std::string filename){

  // Se genera el grafo con la informacion ingresada desde el archivo.
  Grafo.loadDirectedGraph(filename);

  // Se cambia la capacidad de la tabla hash.
  Tabla.setCapacity(SIZE);
  
  // Se obtiene el resumen de informacion de cada IP del grafo.
  Grafo.generateIPSummary();
  // Se obtiene el vector con los registros del grafo
  Registros = Grafo.getRegistros();

  // Inicio conteo de tiempo de ejecución
  //auto startTime = std::chrono::high_resolution_clock::now();
  
  // Se insertan los registros en la tabla Hash.
  for (int i=0; i<Registros.size(); i++){
    Tabla.add(Registros[i].getIpDecimal(),Registros[i]);
  }

  // Termina conteo de tiempo de ejecución 
  //auto endTime = std::chrono::high_resolution_clock::now();
  //auto totalTime = endTime - startTime;
  //cout << "Tiempo de ejecución en ms: " << totalTime/std::chrono::milliseconds(1) << endl;
  
  // Se imprime el numero de colisiones de la tabla Hash.
  std::cout << "Numero de colisiones: " << Tabla.getCounterColisiones() << std::endl;

}


// Destructor vacio.
Bitacora::~Bitacora(){
  
}


/* 
 * Método getIPSummary:
 * Descripción: Imprime el resumen completo de una IP ingresada por el usuario y su lista completa de direcciones accesadas desde la IP recibida.
 * Entrada: string 'ipUsuarioEntrada' que es la IP cuya informacion se busca deplegar.
 * Salida: El resumen completo de la información relativa a la IP recibida (valor de la tabla hash) y la lista completa de direcciones accesadas desde la IP recibida, ordenadas en forma ascendente.
 * Precondición: Una bitacora con sus elementos validos y una string IP valida.
 * Postcondición: Si existe el registros, imprimir la informacion relacionada a dicha IP.
 * Complejidad: O(k + (log(V)+ E log(E)) + E) -> O(log(V) + 2E log(E) + k) -> aprox -> O(log(V) + E log(E) + k)
 *      V = numIPs.
 *      E = numConexiones salientes desde la IP insertada por el usuario.
 *      k = numElementos con la llave en la Hash.
*/

void Bitacora::getIPSummary(std::string ipUsuarioEntrada){

  // Se genera un objeto del tipo IpReg con la IP recibida por el usuario.
  std::string ipUsuario = ipUsuarioEntrada;
  IpReg tmpIP(ipUsuario, 0, 0);

  // Se busca el indice en la tabla IP para corroborar que exista dicha IP.
  int index = Tabla.find(tmpIP.getIpDecimal());

  // Se checa si el indice obtenido es valido.
  std::cout << std::endl;
  std::cout << "Result index: " << index << std::endl;
  // Su es invalido, le notifica al usuario.
  if (index == -1)
    std::cout << "\tElement not found" << std::endl;
  // Si es valido, despliega la informacion de dicha IP.
  else{
    // Obtiene la informacion de la tabla en la posicion e IP solicitada.
    std::cout << "\tData: " << Tabla.getDataAt(index) << std::endl;

    // Se obtienen las conexiones salientes de la IP recibida por el usuario.
    Conexiones = Grafo.getConexiones(ipUsuario);

    // Se imprimen las conexiones accesadas por la IP recibida por el usuario en orden ascendente.
    std::cout << "Conexiones accesadas: " << std::endl;
    for (int i=0; i<Conexiones.size(); i++)
      std::cout << i+1 << ": "<< Conexiones[i] << std::endl;
    std::cout << std::endl;
  }
}