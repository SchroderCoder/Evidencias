#ifndef _NODE_H_
#define _NODE_H_

// Clase para el nodo.
template <class T>
class LLNode { 
  public: 
    // Constructor vacio.
    LLNode();
    // Constructor que recibe un valor de tipo generico.
    LLNode(T val);   

    // Variable 'data' de tipo generico.
    T data; 
    // Apuntador del tipo Node<T> para saber que nodo es el siguiente en la lista ligada.
    LLNode<T> *next;
         
}; 

// Constructor vacio de un nuevo nodo 'Node'. Se inicializa el nodo con un valor 'data' igual a '0' y 'next' es un 'nullptr'.
template<class T>
LLNode<T>::LLNode() : data{}, next{nullptr} {}


/*
 * Método Node:
 * Descripción: Genera un nuevo nodo 'Node' con el valor del tipo generico recibido como parametro y 'next' es un 'nullptr'.
 * Entrada: T 'val' que es el valor que tomara la variable 'data' en el nodo.
 * Salida: Ninguna.
 * Precondición: Ingresar un valor generico valido.
 * Postcondición: Se genera un nuevo nodo 'Node'.
 * Complejidad: O(1)
*/

template<class T>
LLNode<T>::LLNode(T val){
  data = val;
  next = nullptr;
}

#endif // _NODE_H_