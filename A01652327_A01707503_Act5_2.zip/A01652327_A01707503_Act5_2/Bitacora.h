#ifndef _BITACORA_H_
#define _BITACORA_H_

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <chrono>

#include "Graph.h"
#include "HashTable.h"



// Distintas variables de tamaño para la tabla Hash para buscar minimizar las colisines.

// 100%
//# define SIZE 13381
// Num colisiones: 6641
// Tiempo en ms: 9,7,7,8,7

// 120%
//# define SIZE 16057
// Num colisiones: 5511
// Tiempo en ms: 4,4,4,4,4

// 130%
//# define SIZE 17383
// Num colisiones: 5110
// Tiempo en ms: 4,4,3,4,4

// 150%
//# define SIZE 20063
// Num colisiones: 4470
// Tiempo en ms: 4,4,4,4,5

// 200%
# define SIZE 26759
// Num colisiones: 3326
// Tiempo en ms: 4,3,3,3,3

// 300%
//# define SIZE 40111
// Num colisiones: 2242
// Tiempo en ms: 7,4,3,4,6

// 400%
//# define SIZE 53479
// Num colisiones: 1662
// Tiempo en ms: 11,3,4,4,3


// Clase para obtener los registros y realizar todo el proceso necesario.
 class Bitacora{

  public:
    // Constructor que recibe como entrada: string 'filename' que es el nombre del archivo de la bitacora. Debe ser un archivo .txt
    Bitacora(std::string filename);
    // Destructor de Bitacora.
    ~Bitacora();

    /*
     * Recibe como entrada una IP que fue solicitada al usuario en pantalla, y la cual se valido para garantizar que existe en la bitácora.
     * Imprime:
     *      El resumen completo de la información relativa a la IP recibida (valor de la tabla hash).
     *      La lista completa de direcciones accesadas desde la IP recibida, ordenadas en forma ascendente.
    */
    void getIPSummary(std::string ipUsuarioEntrada);


  private:
    // Objeto tipo Grafo donde se almacenara toda la informacion.
    Graph Grafo;
    // Objeto tipo HashTable donde se almacenara la informacion relacionada a cada IP.
    HashTable<unsigned int, IpReg> Tabla;
    // Vector de objetos IpReg con las IPs con su valor en formato string y en base decimal, asi como numero de entradas y salidas.
    vector<IpReg> Registros;
    // Vector que contendra los strings de cada IP de conexiones salientes desde la IP recibida por el usuario.
    vector<std::string> Conexiones;
  
};

#endif