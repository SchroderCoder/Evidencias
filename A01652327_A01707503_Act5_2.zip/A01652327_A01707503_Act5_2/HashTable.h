#ifndef __HASH_TABLE_H_
#define __HASH_TABLE_H_

#include <iostream>
#include <vector>
#include <stdexcept>
#include "HashNode.h"

// Clase para la Tabla Hash.
template<class K, class T>
class HashTable {
  private:
    // Vector de nodos 'HashNode' que forman la tabla Hash.
    std::vector<HashNode<K,T>> table;
    // Variable de tipo entero 'size' que almacena el numero de elementos con los que cuenta la tabla hash.
    int size;
    // Variable de tipo entero 'maxSize' que almacena el tamaño maximo de elementos que puede tener la tabla Hash. 
    int maxSize; // preferible un numero primo

    // Variable de tipo entero 'counterColisiones' que almacena el numero de colisiones que se generaron en la tabla.
    int counterColisiones;

  public:
    // Constructor.
    HashTable();
    // Metodo que devuelve el indice en la tabla Hash basandose en el 'keyVal' ingresado.
    int getHashIndex(K keyVal);

    // Metodo que devuelve el tamaño de la tabla Hash.
    int getSize();
    // Metodo que recibe un entero 'capacity' para definirlo como capacidad maxima de la tabla hash.
    void setCapacity(int capacity);
    // Metodo para imprimir la tabla hash.
    void print();
    // Metodo que recibe una llave 'keyVal' y un dato 'value' para agregarlo a la tabla hash.
    void add(K keyVal, T value);
    // Metodo que busca un registro con una llave 'keyVal' que recibe y devuelve el indice.
    int find(K keyVal);
    // Metodo que regresa el contenido en una posicion dada de la tabla hash.
    T getDataAt(int index);
    // Metodo que elimina el valor de la llave 'keyVal' de la tabla.
    void remove(K keyVal);
    // Metodo que devuelve la cantidad de colisiones de la tabla.
    int getCounterColisiones();


};


/*
 * Método HashTable:
 * Descripción: Genera un nuevo objeto 'HashTable'.
 * Entrada: Ninguna.
 * Salida: Ninguna.
 * Precondición: Ninguna.
 * Postcondición: Se genera un nuevo objeto 'HashTable'.
 * Complejidad: O(1)
*/

template<class K, class T>
HashTable<K, T>::HashTable() {
  maxSize = 0;
  size = 0;
  counterColisiones = 0;
  table.resize(maxSize);
}


/*
 * Método setCapacity:
 * Descripción: Asigna a la tabla una capacidad maxima 'capacity'.
 * Entrada: Entero 'capacity' que es la capacidad maxima.
 * Salida: Ninguna.
 * Precondición: Una tabla hash y un entero 'capacity' validos.
 * Postcondición: Una tabla hash actualizada con la capacidad ingresada.
 * Complejidad: O(k)
 *      k = Valor de la capacidad ingresada.
*/

template<class K, class T>
void HashTable<K, T>::setCapacity(int capacity) { // Complejidad: O(n)
  maxSize = capacity;
  size = 0;
  counterColisiones = 0;
  table.resize(capacity);
}


/*
 * Método getHashIndex:
 * Descripción: Devuelve el valor del indice de la tabla dada una llave 'keyVal'.
 * Entrada: Variable generica tipo K 'keyVal' que es la llave de la que se quiere obtener el indice.
 * Salida: Devuelve el valor calculado del indice de la tabla.
 * Precondición: Una tabla valida.
 * Postcondición: Devuelve el valor calculado del indice de la tabla.
 * Complejidad: O(1)
*/

template<class K, class T>
int HashTable<K, T>::getHashIndex(K keyVal) {
  return keyVal % maxSize;
}


/*
 * Método getSize:
 * Descripción: Devuelve el valor de la variable 'size' que es la cantidad de elementos de la tabla.
 * Entrada: Ninguna.
 * Salida: El valor de la variable 'size'.
 * Precondición: Una tabla valida.
 * Postcondición: Devuelve el valor de 'size' de la tabla.
 * Complejidad: O(1)
*/

template<class K, class T>
int HashTable<K, T>::getSize() {
  return size;
}


/*
 * Método print:
 * Descripción: Imprime el contenido de cada uno de los espacios utilizados de la tabla.
 * Entrada: Ninguna.
 * Salida: Todo el contenido de cada uno de los espacios utilizados de la tabla.
 * Precondición: Una tabla valida.
 * Postcondición: Impresion de todo el contenido de cada uno de los espacios utilizados de la tabla.
 * Complejidad: O(n)
 *      n = Capacidad maxima de la tabla hash.
*/

template<class K, class T> 
void HashTable<K,T>::print() {
  std::cout << "Content of the hash table: " << std::endl;
  for (int i = 0; i < maxSize; i++) {
    // status:  0 empty, 1 used, 2 deleted
    if (table[i].getStatus() == 1) // Cell is used
      std::cout << "Cell: " << i << " Key: " << table[i].getKey() << ", Value: " << table[i].getData() << ", Overflow.size: " << table[i].getOverflowSize() << std::endl;
  }
}


/*
 * Método add:
 * Descripción: Inserta un elemento en la tabla hash.
 * Entrada: Variable de tipo generico K de la llave 'keyVal' y variable de tipo generico T 'value' con el contenido a insertar a la tabla.
 * Salida: En caso de que la tabla este llena se le notifica al usuario.
 * Precondición: Una tabla y variables 'keyVal', 'value' validos.
 * Postcondición: Una estructura modificada con el dato nuevo.
 * Complejidad: O(1+k) -> aprox -> O(k)    Promedio: O(1), mientras mas llena, mas aumenta.
 *      k = Tamaño del overflow
*/

template<class K, class T>
void HashTable<K,T>::add(K keyVal, T value) { //Promedio: O(1)
  if (size == maxSize) {
    throw std::out_of_range("Hash Table is full");
  }
  // Compute the index of the table using a key and a hash function
  int hashVal = getHashIndex(keyVal); 
  HashNode<K, T> node = table[hashVal];
  // status:  0 empty, 1 used, 2 deleted
  if (node.getStatus() != 1) { // Cell is free
    node.setKey(keyVal);
    node.setData(value);
    table[hashVal] = node;
  }
  else { // Cell is already taken
    // Find next free space using quadratic probing
    // https://www.geeksforgeeks.org/quadratic-probing-in-hashing/
    int i = 1;
    int currentHashVal = getHashIndex(hashVal + i * i);
    HashNode<K, T> currentNode = table[currentHashVal];
    while (currentNode.getStatus() == 1) { // Cell is used
      i++;
      currentHashVal = getHashIndex(hashVal + i * i);
      currentNode = table[currentHashVal];
    }
    // A free cell was found
    currentNode.setKey(keyVal);
    currentNode.setData(value);
    node.addToOverflow(currentHashVal);
    table[currentHashVal] = currentNode;
    table[hashVal] = node;
    counterColisiones++;
  }
  size++;
}  


/*
 * Método find:
 * Descripción: Devuelve el indice de la tabla hash de la llave ingresada 'keyVal'.
 * Entrada: Variable generica tipo K 'keyVal' que es la llave de la que se quiere obtener el indice.
 * Salida: Devuelve el indice de la tabla hash de la llave ingresada 'keyVal'.
 * Precondición: Una tabla hash valida y una llave 'keyVal' valida.
 * Postcondición: Devuelve el indice de la tabla hash de la llave ingresada 'keyVal'.
 * Complejidad: O(k)
 *      k = tamaño del overflow.
*/

template<class K, class T>
int HashTable<K,T>::find(K keyVal) {
  int hashVal = getHashIndex(keyVal); 
  HashNode<K, T> node = table[hashVal];
  // status:  0 empty, 1 used, 2 deleted
  if (node.getStatus() == 1) { // Cell is used
    if (node.getKey() == keyVal) {
      return hashVal;
    }
    for (int i = 0; i < node.getOverflowSize(); i++) {
      int overflowIndex = node.getOverflowAt(i);
      if (table[overflowIndex].getKey() == keyVal) {
        return overflowIndex;
      }
    }
    return -1;
  }
  return -1;
}


/*
 * Método getDataAt:
 * Descripción: Devuelve el valor de 'data' de la posicion ingresada.
 * Entrada: Entero 'index' de la posicion de la que se desea obtener el contenido.
 * Salida: Ninguna.
 * Precondición: Una tabla hash valida.
 * Postcondición: Devuelve el valor de 'data' de la posicion ingresada.
 * Complejidad: O(1)
*/

template<class K, class T>
T HashTable<K,T>::getDataAt(int index) { //O(1)
  return table[index].getData();
}


/*
 * Método remove:
 * Descripción: Elimina un dato con llave 'keyVal' de la tabla hash.
 * Entrada: Llave de tipo generico K 'keyVal'.
 * Salida: En caso de no existir el elemento, se notifica al usuario.
 * Precondición: Una tabla hash valida y una llave 'keyVal' valida.
 * Postcondición: Una estructura modificada.
 * Complejidad: O(1+k) -> aprox -> O(k)
 *      k = Tamaño del overflow
*/

template<class K, class T>
void HashTable<K,T>::remove(K keyVal) { //Complejidad O(k) k=tamaño del overflow
  int pos, hashVal;
  pos = find(keyVal);
  if (pos == -1) {
    throw std::invalid_argument("Element does not exist in hash table");
  }
  hashVal = getHashIndex(keyVal);
  if (pos != hashVal) {
    HashNode<K, T> node = table[hashVal];
    node.removeFromOverflow(pos);
    table[hashVal] = node;
  }
  table[pos].clearData(); 
}


/*
 * Método getCounterColisiones:
 * Descripción: Devuelve el valor de la variable 'counterColisiones' que es la cantidad de colisiones de la tabla.
 * Entrada: Ninguna.
 * Salida: El valor de la variable 'counterColisiones'.
 * Precondición: Una tabla valida.
 * Postcondición: Devuelve el valor de 'counterColisiones' de la tabla.
 * Complejidad: O(1)
*/

template<class K, class T>
int HashTable<K,T>::getCounterColisiones(){ 
  return counterColisiones;
}


#endif // __HASH_TABLE_H_