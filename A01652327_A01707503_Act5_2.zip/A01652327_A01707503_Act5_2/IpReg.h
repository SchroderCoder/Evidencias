#ifndef _IPREG_H_
#define _IPREG_H_

#include <iostream>
#include <string>
#include <vector>
#include <math.h>

using std::string;
using std::endl;
using std::vector;
using std::cout;
using std::ostream;

// Clase para los registros de Ips y su contador.
class IpReg{

  public:
  	// Constructor vacio.
    IpReg();
    // Constructor que recibe como entrada: string 'ipI', int 'counterEntradasI', int 'counterSalidasI' para generar un registro.
    IpReg(string ipI, int counterEntradasI, int counterSalidasI);
    // Destructor del registro.
    ~IpReg();

    // Metodo para regresar un unsigned int del valor de la IP en formato decimal (variable 'ipDecimal').
    unsigned int getIpDecimal();
    // Metodo para regresar un string de la IP (variable 'ip').
    std::string getIp();

    // Sobrecarga de operadores comparativos para comparar registros utilizando su valor de IP en base decimal.
    bool operator ==(const IpReg&);
    bool operator !=(const IpReg&);
    bool operator >(const IpReg&);
    bool operator <(const IpReg&);
    bool operator <=(const IpReg&);
    bool operator >=(const IpReg&);

    // Sobrecarga de operador << para imprimir toda la informacion del registro.
    friend ostream& operator<<(ostream& os, const IpReg& ipReg);

  private:
  	/*
     * Variables que seran parte de cada registro:
     *
     *   String 'ip' para almacenar la direcion ip de cada registro.
     *
     *   Unsigned int 'ipDecimal' para almacenar el valor de la ip de base 256 en base decimal.
     *
     *   Entero 'counterEntradas' para almacenar la cantidad de veces que la IP recibe una conexion.
     *
     *   Entero 'counterSalidas' para almacenar la cantidad de veces que desde la IP sale una conexion.
    */
    string ip;
    unsigned int ipDecimal;
    int counterEntradas;
    int counterSalidas;
    
};

#endif