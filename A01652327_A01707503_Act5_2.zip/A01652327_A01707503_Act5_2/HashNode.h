#ifndef __HASH_NODE_H_
#define __HASH_NODE_H_

#include <vector>
#include <algorithm>
#include <iterator>

// Clase para el nodo de la tabla hash.
template<class K, class T>
class HashNode {
  private:
    // Variable 'key' de tipo generico K para la llave de cada elemento.
    K key;
    // Variable 'data' de tipo generico T para el dato almacenado en el nodo.
    T data;
    // Variable 'status' de tipo entero para el status del nodo.
    int status;  // 0 empty, 1 used, 2 deleted
    // Vector de enteros overflow para las colisiones.
    std::vector<int> overflow; // used to easily find collision elements  

  public:
    // Constructor vacio.
    HashNode();
    // Metodo para recuperar la variable 'key' de tipo generico K.
    K getKey();
    // Metodo para recuperar la variable 'data' de tipo generico T.
    T getData();
    // Metodo para recuperar la variable 'status' de tipo entero.
    int getStatus();

    // Metodo para asignar una llave en la variable 'key' del nodo.
    void setKey(K keyVal);
    // Metodo para asignar el contenido del nodo en la variable 'data'.
    void setData(T dataVal);
    // Metodo para eliminar el contenido del nodo.
    void clearData();

    // Metodo para agregar un indice que sea de overflow al nodo.
    void addToOverflow(int hashIndex);
    // Metodo para obtener el numero de colisiones de dicho nodo.
    int getOverflowSize();
    // Metodo para obtener el overflow de cierto indice.
    int getOverflowAt(int index);
    // Metodo para remover un elemento del overflow.
    void removeFromOverflow(int value);
    
};


/*
 * Método HashNode:
 * Descripción: Genera un nuevo nodo 'HashNode'.
 * Entrada: Ninguna.
 * Salida: Ninguna.
 * Precondición: Ninguna.
 * Postcondición: Se genera un nuevo nodo 'HashNode'.
 * Complejidad: O(1)
*/

template<class K, class T>
HashNode<K,T>::HashNode() {
  key = 0;
  status = 0;
}


/*
 * Método getKey:
 * Descripción: En caso de que el nodo cuente con informacion (status == 1), devuelve el valor de la variable 'key'. En caso de no contar con informacion le notifica al usuario.
 * Entrada: Ninguna.
 * Salida: El valor de la variable 'key' del nodo de tipo generico K.
 * Precondición: Un nodo valido.
 * Postcondición: Devuelve el valor de 'key' del nodo.
 * Complejidad: O(1)
*/

template<class K, class T>
K HashNode<K,T>::getKey() {
  if (status != 1) throw "Invalid operation: Empty node";
  return key;
}


/*
 * Método getData:
 * Descripción: Devuelve el valor de la variable 'data'.
 * Entrada: Ninguna.
 * Salida: El valor de la variable 'data' del nodo de tipo generico T.
 * Precondición: Un nodo valido.
 * Postcondición: Devuelve el valor de 'data' del nodo.
 * Complejidad: O(1)
*/

template<class K, class T>
T HashNode<K,T>::getData() {
  return data;
}


/*
 * Método getStatus:
 * Descripción: Devuelve el valor de la variable 'status'.
 * Entrada: Ninguna.
 * Salida: El valor de la variable 'status' del nodo de tipo entero.
 * Precondición: Un nodo valido.
 * Postcondición: Devuelve el valor de 'status' del nodo.
 * Complejidad: O(1)
*/

template<class K, class T>
int HashNode<K,T>::getStatus() {
  return status;
}


/*
 * Método setKey:
 * Descripción: Asigna a un nodo en la variable 'key' el valor ingresado por el usuario.
 * Entrada: 'keyVal' de tipo generico K.
 * Salida: Ninguna.
 * Precondición: Un nodo valido y una entrada 'keyVal' de tipo generico K valida.
 * Postcondición: Se le asigna a la variable 'key' el valor ingresado.
 * Complejidad: O(1)
*/

template<class K, class T>
void HashNode<K,T>::setKey(K keyVal) {
  key = keyVal;
}


/*
 * Método setData:
 * Descripción: En caso de estar vacio, asigna a un nodo en la variable 'data' el valor ingresado por el usuario. En caso de estar ocupado notifica al usuario.
 * Entrada: 'dataVal' de tipo generico T.
 * Salida: Ninguna.
 * Precondición: Un nodo valido y una entrada 'dataVal' de tipo generico T valida.
 * Postcondición: Se le asigna a la variable 'data' el valor ingresado y la variable 'status' toma el valor de 1.
 * Complejidad: O(1)
*/

template<class K, class T>
void HashNode<K,T>::setData(T dataVal) {
  if (status == 1) throw "Node has been taken";
  data = dataVal;
  status = 1;
}


/*
 * Método clearData:
 * Descripción: Cambia el 'status' del nodo para estar disponible.
 * Entrada: Ninguna.
 * Salida: Ninguna.
 * Precondición: Un nodo valido.
 * Postcondición: La variable 'status' toma el valor de 0.
 * Complejidad: O(1)
*/

template<class K, class T>
void HashNode<K,T>::clearData() {
    status = 0;
}


/*
 * Método addToOverflow:
 * Descripción: Agrega un indice 'hashIndex' al vector de overflow.
 * Entrada: Entero 'hashIndex' que es la posicion del overflow en la tabla Hash.
 * Salida: Ninguna.
 * Precondición: Un nodo valido y un indice 'hashIndex' valido.
 * Postcondición: El vector actualizado con el valor 'hashIndex'.
 * Complejidad: O(1)
*/

template<class K, class T>
void HashNode<K,T>::addToOverflow(int hashIndex) {
  overflow.push_back(hashIndex);
}


/*
 * Método getOverflowSize:
 * Descripción: Devuelve el tamaño del vector 'overflow'.
 * Entrada: Ninguna.
 * Salida: El tamaño del vector 'overflow'.
 * Precondición: Un nodo valido.
 * Postcondición: Devuelve el tamaño del vector 'overflow'.
 * Complejidad: O(1)
*/

template<class K, class T>
int HashNode<K,T>::getOverflowSize() {
  return overflow.size();
}


/*
 * Método getOverflowAt:
 * Descripción: Regresa el valor del vector 'overflow' en la posicion ingresada.
 * Entrada: Entero 'index' que es la posicion en el vector 'overflow'.
 * Salida: Ninguna.
 * Precondición: Un nodo valido, un vector 'overflow' valido y un entero 'index'.
 * Postcondición: Devuelve el valor del vector 'overflow' en la posicion 'index'.
 * Complejidad: O(1)
*/

template<class K, class T>
int HashNode<K,T>::getOverflowAt(int index) {
  return overflow[index];
}


/*
 * Método RemoveFromOverflow:
 * Descripción: Elimina del vector de overflow un valor recibido.
 * Entrada: Entero 'value' que es el elemento a borrar.
 * Salida: Ninguna.
 * Precondición: Un nodo valido.
 * Postcondición: Si el elemento se encuentra en el vector 'overflow', debe ser borrado y quedara el vector modificado.
 * Complejidad: O(k)
 *       k = numero de elementos en el vector de overflow.
*/

template<class K, class T>
void HashNode<K,T>::removeFromOverflow(int value) {
  std::vector<int>::iterator it = std::find(overflow.begin(), overflow.end(), value);
  // If element was found remove it
  if (it != overflow.end()) {
    // remove element from overflow vector 
    overflow.erase(overflow.begin()+(it - overflow.begin()));
  }
}


#endif // __HASH_NODE_H_