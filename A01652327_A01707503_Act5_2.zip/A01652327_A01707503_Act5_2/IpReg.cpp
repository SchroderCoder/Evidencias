#include "IpReg.h"


// Constructor vacio de un nuevo objeto del tipo IpReg.
IpReg::IpReg(){
  ip = "";
  ipDecimal = 0;
  counterEntradas = 0;
  counterSalidas = 0;
}


/*
 * Método IpReg:
 * Descripción: Genera un objeto del tipo IpReg con sus variables tomando los valores recibidos en los parametros.
 * Entrada: string 'ipI' que es la direccion ip en formato "v1.v2.v3.v4";
 *          int 'counterEntradasI' que es la cantidad de veces que se entabla una conexion entrante con dicha ip.
 *          int 'counterSalidasI' que es la cantidad de veces que se entabla una conexion saliente desde dicha ip.
 * Salida: Ninguna
 * Precondición: string 'ipI' debe de estar en el formato "v1.v2.v3.v4".
 *               int 'counterEntradasI' debe ser un int.
 *               int 'counterSalidasI' debe ser un int.
 * Postcondición: Se genera un nuevo registro con los datos obtenidos.
 * Complejidad: O(1)
*/

IpReg::IpReg(string ipI, int counterEntradasI, int counterSalidasI){
  ip = ipI;
  
  // Generar conversion de ip a decimal
  // Variable donde se almacenara la ip en su equivalente en base decimal de base 256.
  ipDecimal = 0;
  
  // Variable temporal para cada octeto de la ip.
  int temp = 0;
  int pos = 0;

  // Se obtiene el primer octeto.
  pos = ipI.find(".");
  temp = std::stoi(ipI.substr(0,pos));
  ipDecimal = ipDecimal + temp*pow(256,3);

  // Se avanza al segundo octeto.
  ipI = ipI.substr(pos+1);

  // Se obtiene el segundo octeto.
  pos = ipI.find(".");
  temp = std::stoi(ipI.substr(0,pos));
  ipDecimal = ipDecimal + temp*pow(256,2);

  // Se avanza al tercer octeto.
  ipI = ipI.substr(pos+1);

  // Se obtiene el tercer octeto.
  pos = ipI.find(".");
  temp = std::stoi(ipI.substr(0,pos));
  ipDecimal = ipDecimal + temp*pow(256,1);

  // Se avanza al cuarto octeto.
  ipI = ipI.substr(pos+1);

  // Se obtiene el cuarto octeto.
  pos = ipI.find(".");
  temp = std::stoi(ipI.substr(0,pos));
  ipDecimal = ipDecimal + temp;

  // Se copian los contadores de entradas y salidas de la ip.
  counterEntradas = counterEntradasI;
  counterSalidas = counterSalidasI;
}


// Destructor del objeto IpReg.
IpReg::~IpReg(){
  
}


/*
 * Método getIpDecimal:
 * Descripción: Regresa un unsigned int con el valor de la IP en base decimal.
 * Entrada: Ninguna.
 * Salida: Unsigned int con el valor de la variable 'ipDecimal'.
 * Precondición: Un registro valido.
 * Postcondición: El regreso del valor de la variable 'ipDecimal'.
 * Complejidad: O(1)
*/

unsigned int IpReg::getIpDecimal(){
  return ipDecimal;
}


/*
 * Método getIp:
 * Descripción: Regresa un string con el valor de la IP.
 * Entrada: Ninguna.
 * Salida: String con el valor de la variable 'ip'.
 * Precondición: Un registro valido.
 * Postcondición: El regreso del valor de la variable 'ip'.
 * Complejidad: O(1)
*/

std::string IpReg::getIp(){
  return ip;
}


/*
 * Método Sobrecarga de '==':
 * Descripción: Sobre carga el operador '==' para saber si la variable 'ipDecimal' de dos registros es igual.
 * Entrada: Dos registros.
 * Salida: Valor booleano del resultado de la comparacion realizada entre las variables 'ipDecimal' de cada registro.
 * Precondición: Dos registros con variables 'ipDecimal' validas.
 * Postcondición: Valor booleano sobre si son o no iguales las variables 'ipDecimal'.
 * Complejidad: O(1)
*/

bool IpReg::operator==(const IpReg &other) {
  return this->ipDecimal == other.ipDecimal;
}


/*
 * Método Sobrecarga de '!=':
 * Descripción: Sobre carga el operador '!=' para saber si la variable 'ipDecimal' de dos registros es distinta.
 * Entrada: Dos registros.
 * Salida: Valor booleano del resultado de la comparacion realizada entre las variables 'ipDecimal' de cada registro.
 * Precondición: Dos registros con variables 'ipDecimal' validas.
 * Postcondición: Valor booleano sobre si son o no distintas las variables 'ipDecimal'.
 * Complejidad: O(1)
*/

bool IpReg::operator!=(const IpReg &other) {
  return this->ipDecimal != other.ipDecimal;
}


/*
 * Método Sobrecarga de '>':
 * Descripción: Sobre carga el operador '>' para saber si la variable 'ipDecimal' del primer registro es mayor que la del segundo.
 * Entrada: Dos registros.
 * Salida: Valor booleano del resultado de la comparacion realizada entre las variables 'ipDecimal' de cada registro.
 * Precondición: Dos registros con variables 'ipDecimal' validas.
 * Postcondición: Valor booleano sobre si la variable 'ipDecimal' del primer registro es mayor que la del segundo.
 * Complejidad: O(1)
*/

bool IpReg::operator>(const IpReg &other) {
  return this->ipDecimal > other.ipDecimal;
}


/*
 * Método Sobrecarga de '<':
 * Descripción: Sobre carga el operador '<' para saber si la variable 'ipDecimal' del primer registro es menor que la del segundo.
 * Entrada: Dos registros.
 * Salida: Valor booleano del resultado de la comparacion realizada entre las variables 'ipDecimal' de cada registro.
 * Precondición: Dos registros con variables 'ipDecimal' validas.
 * Postcondición: Valor booleano sobre si la variable 'ipDecimal' del primer registro es menor que la del segundo.
 * Complejidad: O(1)
*/

bool IpReg::operator<(const IpReg &other) {
  return this->ipDecimal < other.ipDecimal;
}


/*
 * Método Sobrecarga de '<=':
 * Descripción: Sobre carga el operador '<=' para saber si la variable 'ipDecimal' del primer registro es menor o igual que la del segundo.
 * Entrada: Dos registros.
 * Salida: Valor booleano del resultado de la comparacion realizada entre las variables 'ipDecimal' de cada registro.
 * Precondición: Dos registros con variables 'ipDecimal' validas.
 * Postcondición: Valor booleano sobre si la variable 'ipDecimal' del primer registro es menor o igual que la del segundo.
 * Complejidad: O(1)
*/

bool IpReg::operator<=(const IpReg &other) {
  return this->ipDecimal <= other.ipDecimal;
}


/*
 * Método Sobrecarga de '>=':
 * Descripción: Sobre carga el operador '>=' para saber si la variable 'ipDecimal' del primer registro es mayor o igual que la del segundo.
 * Entrada: Dos registros.
 * Salida: Valor booleano del resultado de la comparacion realizada entre las variables 'ipDecimal' de cada registro.
 * Precondición: Dos registros con variables 'ipDecimal' validas.
 * Postcondición: Valor booleano sobre si la variable 'ipDecimal' del primer registro es mayor o igual que la del segundo.
 * Complejidad: O(1)
*/

bool IpReg::operator>=(const IpReg &other) {
  return this->ipDecimal >= other.ipDecimal;
}


/*
 * Método Sobrecarga de '<<':
 * Descripción: Sobre carga el operador '<<' para generar y devolver un string con todos los datos de cada registro.
 * Entrada: Un Registro valido.
 * Salida: String con la ip y numero tanto de ingresos como salidas de cada registro. Ejemplo: ip: 142.248.253.242 ----- ingresos: 15 ----- salidas: 10
 * Precondición: Tener un registro valido con ip y contadores.
 * Postcondición: string con los datos del registro.
 * Complejidad: O(1)
*/

ostream& operator<<(ostream& os, const IpReg& ipReg)
{
  string registro;
  registro += "ip: " + ipReg.ip + " ----- ";
  registro += "ingresos: " + std::to_string(ipReg.counterEntradas) + " ----- ";
  registro += "salidas: " + std::to_string(ipReg.counterSalidas) + "\n";
  os << registro;
  return os;
}