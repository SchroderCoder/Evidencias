#ifndef _LINKEDLIST_H_
#define _LINKEDLIST_H_

#include<iostream>
#include <stdexcept>
#include "LLNode.h"

// Clase para Lista Ligada 'LinkedList'
template <class T>
class LinkedList {

  private:
    // Apuntador 'head' Node<T> para el primer nodo de la lista.
    LLNode<T>* head;
// Apuntador 'head' Node<T> para el ultimo nodo de la lista.
    LLNode<T>* tail;
    // Variable del tipo entero 'numElements' que almacena el numero de elementos con los que cuenta la lista ligada.
    int numElements;


  public:
    // Constructor.
    LinkedList();
    // Destructor.
    ~LinkedList();

    // Metodo que devuelve el numero de elementos con los que cuenta la lista ligada.
    int getNumElements();
    // Metodo que imprime todos los valores de la lista ligada.
    void printList();
    // Metodo que imprime el ultimo nodo de la lista.
    void printLastNode();
    // Metodo que agrega un elemento al inicio de la lista.
    void addFirst(T value);
    // Metodo que agrega un elemento al final de la lista.
    void addLast(T value);

    // Metodo que obtiene el valor de la lista en la posicion recibida como parametro.
    T getData(int position);
    // Metodo que obtiene el apuntador del primer nodo de la lista.
    LLNode<T>* getHead();
};


/*
 * Método LinkedList:
 * Descripción: Genera una lista ligada 'LinkedList' de tipo generico vacia.
 * Entrada: Ninguna.
 * Salida: Ninguna.
 * Precondición: Tipo de dato generico valido.
 * Postcondición: Estructura de datos creada valida.
 * Complejidad: O(1)
*/

template<class T>
LinkedList<T>::LinkedList() {
  head = nullptr;
  tail = nullptr;
  numElements = 0;
}


/*
 * Método ~LinkedList:
 * Descripción: Destructor de la lista ligada. Borra todos los nodos de la lista ligada.
 * Entrada: Ninguna.
 * Salida: Ninguna.
 * Precondición: Una estructura valida.
 * Postcondición: Lista ligada modificada sin elementos.
 * Complejidad: O(n)
*/

template<class T>
LinkedList<T>::~LinkedList() {
  LLNode<T> *p, *q;
  p = head;
  while (p != nullptr) {
    q = p->next;
    delete p;
    p = q;
  }
  head = nullptr;
  tail = nullptr;
  numElements = 0;
}



/*
 * Método getNumElements:
 * Descripción: Regresa el numero de elementos con los que cuenta la lista.
 * Entrada: Ninguna.
 * Salida: Numero de elementos con los que cuenta la lista.
 * Precondición: Una estructura valida.
 * Postcondición: Retorno del numero de elementos con los que cuenta la lista.
 * Complejidad: O(1)
*/

template<class T>
int LinkedList<T>::getNumElements() {
  return numElements;
}


/*
 * Método printList:
 * Descripción: Imprime los valores de la variable 'data' de cada uno de los nodos de la lista.
 * Entrada: Ninguna.
 * Salida: Todos los valores de la variable 'data' de cada uno de los nodos de la lista.
 * Precondición: Una estructura valida.
 * Postcondición: Impresion de los valores de la variable 'data' de cada uno de los nodos de la lista.
 * Complejidad: O(n)
*/

template<class T>
void LinkedList<T>::printList() {
  LLNode<T> *ptr = head;
  while (ptr != nullptr) {
    std::cout << ptr->data << " ";
    ptr = ptr->next;
  }
  std::cout << std::endl;
}


/*
 * Método printLastNode:
 * Descripción: Imprime el valor de la variable 'data' del ultimo nodo.
 * Entrada: Ninguna.
 * Salida: Valor de la variable 'data' del ultimo nodo de la lista.
 * Precondición: Una estructura valida.
 * Postcondición: Impresion del valor de la variable 'data' del ultimo nodo de la lista.
 * Complejidad: O(n)
*/

template<class T>
void LinkedList<T>::printLastNode() {
  std::cout << tail->data << std::endl;
}


/*
 * Método addFirst:
 * Descripción: Inserta un elemento al principio de la lista.
 * Entrada: Elemento a insertar.
 * Salida: Estructura de datos con el nuevo elemento.
 * Precondición: Una estructura valida.
 * Postcondición: Una estructura modificada con el dato nuevo.
 * Complejidad: O(1)
*/

template<class T>
void LinkedList<T>::addFirst(T value) {
  LLNode<T> *newLLNode = new LLNode<T>(value);
  newLLNode->next = head;
  head = newLLNode;
  if (numElements == 0) 
    tail = newLLNode;
  numElements++;    
}


/*
 * Método addLast:
 * Descripción: Inserta un elemento al final de la lista.
 * Entrada: Elemento a insertar.
 * Salida: Estructura de datos con el nuevo elemento.
 * Precondición: Una estructura valida.
 * Postcondición: Una estructura modificada con el dato nuevo.
 * Complejidad: O(1).
*/

template<class T>
void LinkedList<T>::addLast(T value) {
  // En caso de que la lista se encuentre vacia, se agrega al inicio.
  if (head == nullptr) {
    addFirst(value);
  }
  // En caso de que la lista no se encuentre vacia, se agrega despues del ultimo nodo.
  else {
    LLNode<T> *newLLNode = new LLNode<T>(value);
    newLLNode->next = nullptr;
    tail->next = newLLNode;
    tail = newLLNode;
    numElements++;
  }
}


/*
 * Método getData:
 * Descripción: Lee el valor de un dato de la lista, de acuerdo con la posicion recibida como parametro de entrada.
 * Entrada: Posicion de la lista del elemento que se desea leer.
 * Salida: El dato que se encuentra en esa posicion, en dado caso de que no se encuentre o que la posicion sea invalida, regresa una excepcion de Out_Of_Range.
 * Precondición: Una estructura valida.
 * Postcondición: Una estructura modificada.
 * Complejidad: O(n)
*/

template<class T>
T LinkedList<T>::getData(int position) {
  if (position < 0 || position >= numElements) {
    throw std::out_of_range("Indice fuera de rango");
  }
  else {
    T results = {};
    if (position == 0)
      return head->data;
    LLNode<T> *p = head;
    int index = 0;
    while (p != nullptr) {
      if (index == position)
        return p->data;
      index++;
      p = p->next;
    }
    return results;
  }
}


/*
 * Método getHead:
 * Descripción: Devuelve el apuntador head de la lista.
 * Entrada: Ninguna.
 * Salida: El apuntador hacia el primer nodo de la lista.
 * Precondición: Una estructura valida.
 * Postcondición: Devolver el apuntador del primer nodo.
 * Complejidad: O(1)
*/

template<class T>
LLNode<T>* LinkedList<T>::getHead(){
  return head;
}

#endif // _LINKEDLIST_H_